/* PhishGuard · popup.js
 * 由 core.js + ui-common.js + popup.js 三段拼装而成，修改请回到源文件。
 */
/* ============================================================================
 * PhishGuard · 核心模块（检测引擎 / 看板娘立绘 / 台词库 / 本地存储）
 * 该段代码在网页版和插件版中完全一致，属于唯一事实来源。
 * 纯原生实现，无任何依赖，不发起网络请求。
 * ========================================================================== */
(function (root) {
  'use strict';

  /* ---------------------------------------------------------------- 常量 --- */

  // 短链接服务：目标地址不可见，常被用于隐藏钓鱼落地页
  const SHORT_LINKS = [
    'bit.ly', 't.cn', 'tinyurl.com', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly',
    'rb.gy', 'cutt.ly', 'shorturl.at', 'rebrand.ly', 'tiny.cc', 'v.gd', 's.id'
  ];

  // 高滥用率顶级域名
  const RISKY_TLDS = ['xyz', 'top', 'club', 'info', 'work', 'icu', 'buzz', 'wang', 'tk', 'pw'];

  // 常见被仿冒品牌 → 官方域名白名单
  const BRANDS = {
    paypal: ['paypal.com', 'paypal.me'],
    apple: ['apple.com', 'icloud.com'],
    google: ['google.com', 'google.cn', 'gmail.com', 'youtube.com'],
    taobao: ['taobao.com', 'tmall.com'],
    alipay: ['alipay.com', 'alipay.cn'],
    icbc: ['icbc.com.cn', 'icbc.com'],
    wechat: ['wechat.com', 'weixin.qq.com'],
    qq: ['qq.com'],
    jd: ['jd.com'],
    amazon: ['amazon.com', 'amazon.cn'],
    microsoft: ['microsoft.com', 'live.com'],
    netflix: ['netflix.com'],
    steam: ['steampowered.com', 'steamcommunity.com'],
    bank: [
      'bankofchina.com', 'boc.cn', 'ccb.com', 'abchina.com', 'cmbchina.com',
      'bankcomm.com', 'cebbank.com', 'psbc.com', 'bankofamerica.com',
      'chase.com', 'wellsfargo.com', 'citibank.com', 'hsbc.com'
    ]
  };

  const LEVEL_META = {
    safe: { label: '安全', en: 'SAFE', tone: 'mint' },
    warn: { label: '可疑', en: 'CAUTION', tone: 'gold' },
    danger: { label: '危险', en: 'DANGER', tone: 'coral' },
    idle: { label: '待机', en: 'STANDBY', tone: 'pink' }
  };

  /* ------------------------------------------------------------ 检测引擎 --- */

  function isIpHost(host) {
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host)) {
      return host.split('.').every(function (n) { return Number(n) <= 255; });
    }
    return /^\[[0-9a-f:]+\]$/i.test(host); // IPv6
  }

  function officialHost(host, list) {
    return list.some(function (d) { return host === d || host.endsWith('.' + d); });
  }

  function countChars(str, chars) {
    let n = 0;
    for (let i = 0; i < str.length; i++) if (chars.indexOf(str[i]) !== -1) n++;
    return n;
  }

  /**
   * 对一条 URL 做 12 项特征分析。
   * @param {string} raw 用户输入
   * @returns {{ok:boolean, error?:string, url?:string, host?:string, protocol?:string,
   *            score?:number, level?:string, results?:Array, hits?:Array}}
   */
  function analyze(raw) {
    const input = String(raw == null ? '' : raw).trim();
    if (!input) return { ok: false, error: '请先输入一个网址，再开始检测哦。' };
    if (input.length > 2048) return { ok: false, error: '这个网址太长了，超过 2048 个字符无法分析。' };

    const hasScheme = /^[a-z][a-z0-9+.\-]*:\/\//i.test(input);
    let parsed;
    try {
      parsed = new URL(hasScheme ? input : 'http://' + input);
    } catch (e) {
      return { ok: false, error: '这个网址格式不太对，检查一下是否多打了空格或符号。' };
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return { ok: false, error: '目前只支持 http / https 开头的网址。' };
    }
    if (!parsed.hostname) return { ok: false, error: '没有解析到域名，请检查网址是否完整。' };

    const host = parsed.hostname.toLowerCase();
    const protocol = parsed.protocol.replace(':', '');
    const href = parsed.href;
    const pathAndQuery = parsed.pathname + parsed.search + parsed.hash;
    const results = [];
    const push = function (id, title, status, weight, detail) {
      results.push({ id: id, title: title, status: status, weight: weight, detail: detail });
    };

    /* 1. URL 总长度 —————————————————————————————————————— */
    if (href.length > 100) {
      push('length', 'URL 长度', 'danger', 30,
        'URL 共 ' + href.length + ' 个字符，超过 100 字符的危险阈值，正常页面地址很少这么长。');
    } else if (href.length > 75) {
      push('length', 'URL 长度', 'warn', 15,
        'URL 共 ' + href.length + ' 个字符，超过 75 字符的可疑阈值。');
    } else {
      push('length', 'URL 长度', 'safe', 0, href.length + ' 个字符，长度正常。');
    }

    /* 2. IP 地址作为主机名 ———————————————————————————————— */
    if (isIpHost(host)) {
      push('ip', 'IP 地址主机', 'danger', 30,
        '主机名「' + host + '」直接使用了 IP 地址。正规网站通常使用域名，用 IP 隐藏身份是钓鱼站的常见做法。');
    } else {
      push('ip', 'IP 地址主机', 'safe', 0, '主机名为正常域名，未直接暴露 IP。');
    }

    /* 3. @ 符号 ———————————————————————————————————————— */
    const atCount = (input.match(/@/g) || []).length;
    if (atCount > 0) {
      push('at', '@ 符号混淆', 'danger', 30,
        '网址中出现 ' + atCount + ' 个 @ 符号。浏览器会忽略 @ 之前的内容，真实域名可能藏在 @ 后面。');
    } else {
      push('at', '@ 符号混淆', 'safe', 0, '未发现 @ 符号。');
    }

    /* 4. HTTPS ————————————————————————————————————————— */
    if (protocol === 'https') {
      push('https', 'HTTPS 加密', 'safe', 0, '使用 HTTPS，传输过程已加密（但加密不代表网站可信）。');
    } else if (!hasScheme) {
      push('https', 'HTTPS 加密', 'warn', 15,
        '输入未写明协议，浏览器会按 http 访问，内容可能被窃听或篡改。');
    } else {
      push('https', 'HTTPS 加密', 'warn', 15,
        '当前为 http 明文连接，登录信息可能被中间人截取。');
    }

    /* 5. 子域名层数 —————————————————————————————————————— */
    const labels = host.split('.');
    const subCount = isIpHost(host) ? 0 : Math.max(0, labels.length - 1);
    if (!isIpHost(host) && subCount > 3) {
      push('subdomain', '子域名层数', 'warn', 15,
        '主机名含 ' + subCount + ' 层子域名：' + host + '。层数过多常被用来伪装成官方站点。');
    } else {
      push('subdomain', '子域名层数', 'safe', 0,
        isIpHost(host) ? 'IP 主机，不适用子域名统计。' : '共 ' + subCount + ' 层子域名，结构正常。');
    }

    /* 6. 短链接服务 —————————————————————————————————————— */
    const shortHit = SHORT_LINKS.find(function (d) { return host === d || host.endsWith('.' + d); });
    if (shortHit) {
      push('shortlink', '短链接跳转', 'warn', 15,
        '「' + shortHit + '」是短链接服务，真实落地页在点击前不可见。');
    } else {
      push('shortlink', '短链接跳转', 'safe', 0, '不是已知的短链接服务。');
    }

    /* 7. 特殊字符占比 ————————————————————————————————————— */
    const special = countChars(pathAndQuery, '-_=?&%#~+');
    const ratio = pathAndQuery.length ? special / pathAndQuery.length : 0;
    if (special >= 8 && ratio >= 0.15) {
      push('special', '特殊字符占比', 'warn', 15,
        '路径与参数中特殊字符占 ' + Math.round(ratio * 100) + '%，结构异常，可能经过刻意混淆。');
    } else {
      push('special', '特殊字符占比', 'safe', 0,
        '特殊字符占比 ' + Math.round(ratio * 100) + '%，在正常范围内。');
    }

    /* 8. 域名数字占比 ————————————————————————————————————— */
    const domainName = labels.length > 1 ? labels.slice(0, -1).join('.') : host;
    const digits = countChars(domainName, '0123456789');
    const digitRatio = domainName.length ? digits / domainName.length : 0;
    if (!isIpHost(host) && digits >= 3 && digitRatio >= 0.3) {
      push('digit', '域名数字占比', 'warn', 15,
        '域名主体里数字占 ' + Math.round(digitRatio * 100) + '%，常见于批量注册的钓鱼域名。');
    } else {
      push('digit', '域名数字占比', 'safe', 0,
        '域名主体数字占比 ' + Math.round(digitRatio * 100) + '%，属正常水平。');
    }

    /* 9. 高风险顶级域名 ————————————————————————————————— */
    const tld = labels[labels.length - 1] || '';
    if (RISKY_TLDS.indexOf(tld) !== -1) {
      push('tld', '高风险顶级域名', 'warn', 15,
        '「.' + tld + '」注册成本低、滥用率高，是钓鱼站的高频选择。');
    } else {
      push('tld', '高风险顶级域名', 'safe', 0, '顶级域名为「.' + tld + '」，不在高风险名单中。');
    }

    /* 10. 品牌仿冒 ————————————————————————————————————— */
    const tokens = host.split(/[.\-_]/);
    const brandHit = Object.keys(BRANDS).find(function (brand) {
      const list = BRANDS[brand];
      if (officialHost(host, list)) return false;          // 官方域名直接放过
      return tokens.some(function (t) {
        if (t === brand) return true;
        if (t.indexOf(brand) === 0) {
          const rest = t.slice(brand.length);
          return /^\d+$/.test(rest);                       // apple123 / taobao1
        }
        return false;
      });
    });
    if (brandHit) {
      push('brand', '品牌仿冒', 'danger', 30,
        '域名中包含品牌词「' + brandHit + '」，但不是官方域名。仿冒站最爱用 apple-id.com 这类地址。');
    } else {
      push('brand', '品牌仿冒', 'safe', 0, '未发现对常见品牌的域名仿冒。');
    }

    /* 11. 路径双斜杠 ————————————————————————————————————— */
    if (parsed.pathname.indexOf('//') !== -1) {
      push('double', '路径双斜杠', 'warn', 15,
        '路径中出现 //，可能被用于跳转到其他站点或绕过路径校验。');
    } else {
      push('double', '路径双斜杠', 'safe', 0, '路径结构正常。');
    }

    /* 12. 域名年龄 ——————————————————————————————————————— */
    push('age', '域名年龄', 'na', 0,
      '纯前端无法查询域名注册时间。若需更准确判断，可在浏览器插件中接入 Whois 接口。');

    /* 汇总打分 */
    let score = 0;
    results.forEach(function (r) { score += r.weight; });
    score = Math.min(100, score);

    let level = score <= 30 ? 'safe' : (score <= 60 ? 'warn' : 'danger');
    // 单项 +30 的高危特征单独命中时，分数落在 30 分“安全”区间，语义上不合理；
    // 因此只要有高危项命中，等级至少提升为「可疑」。
    const hasDangerHit = results.some(function (r) { return r.status === 'danger'; });
    if (hasDangerHit && level === 'safe') level = 'warn';
    const hits = results.filter(function (r) { return r.status === 'warn' || r.status === 'danger'; })
      .sort(function (a, b) { return b.weight - a.weight; });

    return {
      ok: true,
      url: href,
      host: host,
      protocol: protocol,
      score: score,
      level: level,
      results: results,
      hits: hits
    };
  }

  function levelMeta(level) { return LEVEL_META[level] || LEVEL_META.idle; }

  /* ------------------------------------------------------------ 看板娘 --- */
  /* 立绘全部由 SVG 路径绘制：无图片依赖，可任意缩放，且能跟着主题呼吸。    */

  const CHARS = [
    {
      id: 'sakura',
      name: '小樱',
      tag: '元气担当',
      hair: '#FFB7C5',
      hairDark: '#F293AC',
      hairLight: '#FFD9E1',
      eyeLight: '#FFE4EB',
      eyeMain: '#F2769A',
      eyeDark: '#C64C72',
      collar: '#FF9FB3',
      ribbon: '#FF7C9C',
      ribbonDark: '#E85C7D',
      gaze: 'left',

      back: [
        // 后发主体
        '<path d="M200,64 C272,64 322,114 324,196 C326,254 314,306 300,340 C290,366 264,360 258,336 C274,292 276,240 268,200 C258,156 234,132 200,132 C166,132 142,156 132,200 C124,240 126,292 142,336 C136,360 110,366 100,340 C86,306 74,254 76,196 C78,114 128,64 200,64 Z" fill="{hair}"/>',
        '<path d="M200,132 C238,132 262,160 272,204 C282,248 280,300 264,342 C258,318 258,276 248,240 C238,200 220,178 200,178 C180,178 162,200 152,240 C142,276 142,318 136,342 C120,300 118,248 128,204 C138,160 162,132 200,132 Z" fill="{hairDark}" opacity=".34"/>',
        // 双马尾
        '<g class="sway">',
        '<path d="M94,250 C64,300 44,392 50,468 C54,510 78,522 92,500 C102,482 96,430 104,382 C110,340 116,300 116,262 Z" fill="{hair}"/>',
        '<path d="M306,250 C336,300 356,392 350,468 C346,510 322,522 308,500 C298,482 304,430 296,382 C290,340 284,300 284,262 Z" fill="{hair}"/>',
        '<path d="M88,300 C72,350 62,412 66,466" stroke="{hairDark}" stroke-width="3" opacity=".3" fill="none"/>',
        '<path d="M312,300 C328,350 338,412 334,466" stroke="{hairDark}" stroke-width="3" opacity=".3" fill="none"/>',
        '</g>',
        // 发绳蝴蝶结
        '<path d="M96,252 L70,236 L64,264 L96,266 Z" fill="{ribbon}"/>',
        '<path d="M96,252 L120,238 L124,264 L96,266 Z" fill="{ribbon}"/>',
        '<circle cx="96" cy="258" r="6.5" fill="{ribbonDark}"/>',
        '<path d="M304,252 L330,236 L336,264 L304,266 Z" fill="{ribbon}"/>',
        '<path d="M304,252 L280,238 L276,264 L304,266 Z" fill="{ribbon}"/>',
        '<circle cx="304" cy="258" r="6.5" fill="{ribbonDark}"/>'
      ].join(''),

      front: [
        // 刘海
        '<path d="M96,198 C94,122 132,80 200,80 C268,80 306,122 304,198 C298,168 288,146 276,132 C278,164 268,188 256,202 C254,170 244,146 232,134 C234,166 224,190 212,204 C210,172 202,148 192,138 C190,174 182,196 170,206 C168,172 158,150 146,142 C146,174 138,196 126,206 C122,178 112,154 104,144 C104,170 100,186 96,198 Z" fill="{hair}"/>',
        // 高光
        '<path d="M130,126 C152,102 178,94 202,94 C228,94 252,102 272,120" stroke="{hairLight}" stroke-width="7" fill="none" opacity=".42" stroke-linecap="round"/>',
        '<path d="M152,150 C158,130 170,116 184,106" stroke="{hairDark}" stroke-width="2.4" opacity=".28" fill="none"/>',
        '<path d="M248,148 C242,128 232,114 220,106" stroke="{hairDark}" stroke-width="2.4" opacity=".28" fill="none"/>',
        // 鬓发
        '<g class="sway">',
        '<path d="M104,186 C96,222 92,266 94,312 C96,338 106,352 116,346 C110,312 110,262 118,214 Z" fill="{hair}"/>',
        '<path d="M296,186 C304,222 308,266 306,312 C304,338 294,352 284,346 C290,312 290,262 282,214 Z" fill="{hair}"/>',
        '</g>',
        // 呆毛
        '<path d="M196,80 C198,52 210,38 226,32 C214,44 208,58 206,80 Z" fill="{hair}"/>'
      ].join(''),

      extra: ''
    },
    {
      id: 'mint',
      name: '薄荷',
      tag: '冷静担当',
      hair: '#B8E6D0',
      hairDark: '#8FD6B6',
      hairLight: '#DDF8EC',
      eyeLight: '#E4FBF2',
      eyeMain: '#4FB795',
      eyeDark: '#2E8C6E',
      collar: '#7FCFB2',
      ribbon: '#5FC0A0',
      ribbonDark: '#3FA585',
      gaze: 'left',

      back: [
        '<path d="M200,64 C268,64 318,112 320,190 C322,248 310,306 292,342 C284,360 264,354 260,338 C274,300 278,250 270,206 C260,164 234,138 200,138 C166,138 140,164 130,206 C122,250 126,300 140,338 C136,354 116,360 108,342 C90,306 78,248 80,190 C82,112 132,64 200,64 Z" fill="{hair}"/>',
        '<path d="M200,138 C238,138 262,166 270,208 C278,252 274,300 258,340 C252,316 250,272 242,238 C232,200 218,180 200,180 C182,180 168,200 158,238 C150,272 148,316 142,340 C126,300 122,252 130,208 C138,166 162,138 200,138 Z" fill="{hairDark}" opacity=".32"/>',
        '<g class="sway">',
        '<path d="M108,300 C102,330 104,352 112,366 C120,378 134,372 134,356 C128,340 126,318 124,300 Z" fill="{hair}"/>',
        '<path d="M292,300 C298,330 296,352 288,366 C280,378 266,372 266,356 C272,340 274,318 276,300 Z" fill="{hair}"/>',
        '</g>'
      ].join(''),

      front: [
        // 侧分刘海
        '<path d="M98,196 C98,120 136,80 200,80 C264,80 302,120 302,196 C294,166 282,144 266,132 L268,186 C258,176 246,166 232,158 L228,196 C218,178 204,164 188,156 L178,200 C172,178 160,160 146,150 L138,192 C132,172 120,154 108,142 L104,190 C100,182 99,190 98,196 Z" fill="{hair}"/>',
        // 发箍
        '<path d="M104,160 C112,104 150,74 200,74 C250,74 288,104 296,160" stroke="#FFFDFB" stroke-width="14" fill="none" opacity=".95"/>',
        '<path d="M106,156 C114,104 150,78 200,78 C250,78 286,104 294,156" stroke="{hairDark}" stroke-width="3" fill="none" opacity=".35"/>',
        // 发箍小蝴蝶结
        '<path d="M292,120 L316,108 L320,132 L292,134 Z" fill="{ribbon}"/>',
        '<path d="M292,120 L272,110 L268,132 L292,134 Z" fill="{ribbon}"/>',
        '<circle cx="292" cy="126" r="6" fill="{ribbonDark}"/>',
        // 高光与发丝
        '<path d="M134,124 C154,102 178,94 202,94 C226,94 248,100 266,114" stroke="{hairLight}" stroke-width="9" fill="none" opacity=".55" stroke-linecap="round"/>',
        '<path d="M160,146 C166,128 176,116 188,108" stroke="{hairDark}" stroke-width="2.4" opacity=".26" fill="none"/>',
        '<path d="M236,146 C230,128 220,116 210,108" stroke="{hairDark}" stroke-width="2.4" opacity=".26" fill="none"/>',
        // 鬓发（短发，到下颌）
        '<g class="sway">',
        '<path d="M106,184 C100,222 98,258 102,288 C105,306 116,312 124,304 C116,276 116,246 122,210 Z" fill="{hair}"/>',
        '<path d="M294,184 C300,222 302,258 298,288 C295,306 284,312 276,304 C284,276 284,246 278,210 Z" fill="{hair}"/>',
        '</g>'
      ].join(''),

      extra: ''
    },
    {
      id: 'sky',
      name: '天蓝',
      tag: '认真担当',
      hair: '#A8D8EA',
      hairDark: '#7CC4DE',
      hairLight: '#D8F1F9',
      eyeLight: '#E3F6FC',
      eyeMain: '#4F9FC9',
      eyeDark: '#2E78A2',
      collar: '#7FB8D8',
      ribbon: '#6FAFD4',
      ribbonDark: '#4F93BC',
      gaze: 'left',

      back: [
        '<path d="M200,60 C274,60 322,112 324,200 C326,300 318,428 308,512 C302,542 276,538 270,510 C286,400 288,286 278,206 C268,162 236,134 200,134 C164,134 132,162 122,206 C112,286 114,400 130,510 C124,538 98,542 92,512 C82,428 74,300 76,200 C78,112 126,60 200,60 Z" fill="{hair}"/>',
        '<path d="M200,134 C240,134 264,162 272,206 C280,250 280,300 272,360 C266,410 262,460 258,510 C250,500 248,470 250,430 C254,360 250,290 240,240 C230,198 218,180 200,180 C182,180 170,198 160,240 C150,290 146,360 150,430 C152,470 150,500 142,510 C138,460 134,410 128,360 C120,300 120,250 128,206 C136,162 160,134 200,134 Z" fill="{hairDark}" opacity=".3"/>',
        '<path d="M96,360 C92,420 92,470 96,506" stroke="{hairDark}" stroke-width="3" opacity=".3" fill="none"/>',
        '<path d="M304,360 C308,420 308,470 304,506" stroke="{hairDark}" stroke-width="3" opacity=".3" fill="none"/>',
        '<g class="sway">',
        '<path d="M104,196 C92,260 86,350 88,432 C89,458 102,466 110,452 C104,368 106,276 116,216 Z" fill="{hair}"/>',
        '<path d="M296,196 C308,260 314,350 312,432 C311,458 298,466 290,452 C296,368 294,276 284,216 Z" fill="{hair}"/>',
        '</g>',
        // 头顶大蝴蝶结
        '<g class="bow-top" transform="translate(300,96) rotate(-10)">',
        '<path d="M0,0 C-24,-24 -56,-14 -58,8 C-60,28 -34,34 -4,12 Z" fill="{ribbon}"/>',
        '<path d="M0,0 C24,-24 56,-14 58,8 C60,28 34,34 4,12 Z" fill="{ribbon}"/>',
        '<path d="M-4,12 C-10,26 -14,34 -20,40 C-12,36 -6,28 -2,16 Z" fill="{ribbonDark}"/>',
        '<path d="M4,12 C10,26 14,34 20,40 C12,36 6,28 2,16 Z" fill="{ribbonDark}"/>',
        '<circle cx="0" cy="6" r="9" fill="{ribbonDark}"/>',
        '<circle cx="-2" cy="4" r="2.6" fill="#FFFFFF" opacity=".65"/>',
        '</g>'
      ].join(''),

      front: [
        // 齐刘海
        '<path d="M96,196 C96,120 134,80 200,80 C266,80 304,120 304,196 L296,196 C296,170 292,150 288,140 L282,196 C280,166 274,142 266,132 L262,200 C258,168 250,146 240,138 L238,202 C232,170 224,150 214,142 L214,206 C210,172 204,152 196,144 L194,208 C190,174 184,154 176,146 L174,206 C170,172 164,152 156,144 L152,200 C148,168 142,148 134,140 L128,192 C124,168 118,152 110,146 L106,190 C102,176 99,186 96,196 Z" fill="{hair}"/>',
        '<path d="M132,120 C154,100 178,92 202,92 C228,92 250,100 268,114" stroke="{hairLight}" stroke-width="9" fill="none" opacity=".5" stroke-linecap="round"/>',
        '<path d="M158,144 C164,128 172,118 182,110" stroke="{hairDark}" stroke-width="2.4" opacity=".26" fill="none"/>',
        '<path d="M240,144 C234,128 226,118 216,110" stroke="{hairDark}" stroke-width="2.4" opacity=".26" fill="none"/>'
      ].join(''),

      extra: ''
    }
  ];

  const CHAR_MAP = {};
  CHARS.forEach(function (c) { CHAR_MAP[c.id] = c; });

  function paint(str, c) {
    return String(str).replace(/\{(\w+)\}/g, function (m, k) {
      return c[k] == null ? '' : c[k];
    });
  }

  function eyeSVG(c, cx, side) {
    const dir = side === 'left' ? 1 : -1;
    return [
      '<g class="eye eye-' + side + '">',
      '<path d="M' + (cx - 26) + ',208 C' + (cx - 26) + ',184 ' + (cx - 14) + ',172 ' + cx + ',172 C' + (cx + 14) + ',172 ' + (cx + 26) + ',184 ' + (cx + 26) + ',208 C' + (cx + 26) + ',232 ' + (cx + 16) + ',246 ' + cx + ',246 C' + (cx - 16) + ',246 ' + (cx - 26) + ',232 ' + (cx - 26) + ',208 Z" fill="#FFFFFF"/>',
      '<circle cx="' + cx + '" cy="212" r="19" fill="url(#iris-' + c.id + ')"/>',
      '<circle cx="' + cx + '" cy="215" r="9" fill="#4C333C" opacity=".84"/>',
      '<circle cx="' + (cx - 6) + '" cy="204" r="6.5" fill="#FFFFFF"/>',
      '<circle cx="' + (cx + 7) + '" cy="221" r="3.2" fill="#FFFFFF" opacity=".92"/>',
      '<path d="M' + (cx - 26) + ',205 C' + (cx - 24) + ',181 ' + (cx - 12) + ',168 ' + cx + ',168 C' + (cx + 14) + ',168 ' + (cx + 26) + ',182 ' + (cx + 26) + ',205" stroke="#6E4A55" stroke-width="4" fill="none" stroke-linecap="round"/>',
      '<path d="M' + (cx + dir * 26) + ',205 L' + (cx + dir * 31) + ',198" stroke="#6E4A55" stroke-width="3" fill="none" stroke-linecap="round"/>',
      '<path d="M' + (cx - 15) + ',239 C' + (cx - 6) + ',244 ' + (cx + 6) + ',244 ' + (cx + 15) + ',239" stroke="#8C5E68" stroke-width="1.6" fill="none" opacity=".45"/>',
      '</g>'
    ].join('');
  }

  function faceSVG(c) {
    return [
      // 耳朵
      '<ellipse cx="105" cy="212" rx="13" ry="21" fill="url(#skin-' + c.id + ')"/>',
      '<ellipse cx="295" cy="212" rx="13" ry="21" fill="url(#skin-' + c.id + ')"/>',
      '<path d="M104,204 C110,204 112,214 108,222" stroke="#E8AB9E" stroke-width="2" fill="none" opacity=".55"/>',
      '<path d="M296,204 C290,204 288,214 292,222" stroke="#E8AB9E" stroke-width="2" fill="none" opacity=".55"/>',
      // 脸
      '<path d="M200,92 C258,92 294,138 294,196 C294,252 254,310 200,332 C146,310 106,252 106,196 C106,138 142,92 200,92 Z" fill="url(#skin-' + c.id + ')"/>',
      // 刘海投影
      '<path d="M118,168 C140,142 170,130 200,130 C232,130 262,142 284,168 C266,156 238,150 200,150 C162,150 134,156 118,168 Z" fill="' + c.hairDark + '" opacity=".16"/>',
      // 眼睛
      eyeSVG(c, 152, 'left'),
      eyeSVG(c, 248, 'right'),
      // 眉毛（常态 / 担心）
      '<g class="brow brow-normal">',
      '<path d="M128,162 C140,154 154,152 166,156" stroke="' + c.hairDark + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>',
      '<path d="M234,156 C246,152 260,154 272,162" stroke="' + c.hairDark + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>',
      '</g>',
      '<g class="brow brow-worry">',
      '<path d="M128,153 C141,157 154,164 166,170" stroke="' + c.hairDark + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>',
      '<path d="M234,170 C246,164 259,157 272,153" stroke="' + c.hairDark + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>',
      '</g>',
      // 腮红
      '<g class="blush">',
      '<ellipse cx="126" cy="264" rx="20" ry="10" fill="#FF93A6" opacity=".26"/>',
      '<ellipse cx="274" cy="264" rx="20" ry="10" fill="#FF93A6" opacity=".26"/>',
      '<path d="M118,262 L124,268 M126,260 L132,266 M134,258 L140,264" stroke="#FF7E97" stroke-width="1.4" opacity=".35"/>',
      '<path d="M282,262 L276,268 M274,260 L268,266 M266,258 L260,264" stroke="#FF7E97" stroke-width="1.4" opacity=".35"/>',
      '</g>',
      // 鼻子
      '<ellipse cx="200" cy="252" rx="3" ry="2" fill="#E5A092" opacity=".5"/>',
      // 嘴（四种情绪）
      '<g class="mouth mouth-idle"><path d="M187,281 C193,290 207,290 213,281" stroke="#C4707F" stroke-width="3.2" fill="none" stroke-linecap="round"/></g>',
      '<g class="mouth mouth-happy"><path d="M186,278 C193,303 207,303 214,278 C205,285 195,285 186,278 Z" fill="#D9738A"/><path d="M194,288 C198,294 202,294 206,288 C202,292 198,292 194,288 Z" fill="#FFB3C0"/></g>',
      '<g class="mouth mouth-warn"><path d="M190,286 C196,284 204,284 210,286" stroke="#C4707F" stroke-width="3" fill="none" stroke-linecap="round"/></g>',
      '<g class="mouth mouth-danger"><path d="M188,291 C194,283 206,283 212,291" stroke="#C4707F" stroke-width="3.2" fill="none" stroke-linecap="round"/></g>',
      // 冷汗
      '<g class="sweat"><path d="M312,168 C304,182 306,192 314,194 C322,196 326,186 322,176 Z" fill="#BFE9F7" opacity=".9"/><path d="M312,176 C308,184 309,190 314,191" stroke="#FFFFFF" stroke-width="1.6" fill="none" opacity=".7"/></g>'
    ].join('');
  }

  function bodySVG(c) {
    return [
      '<g class="chara-body">',
      // 脖子
      '<path d="M181,300 C181,342 184,358 200,358 C216,358 219,342 219,300 Z" fill="url(#skin-' + c.id + ')"/>',
      '<path d="M181,328 C182,348 190,358 200,358 C210,358 218,348 219,328 Z" fill="#E9A79A" opacity=".22"/>',
      // 连衣裙主体
      '<path d="M200,342 C156,342 126,376 116,424 L108,560 L292,560 L284,424 C274,376 244,342 200,342 Z" fill="#FFFCFA" stroke="#F6DEE7" stroke-width="1.6"/>',
      '<path d="M116,424 L108,560 L292,560 L284,424 C270,446 236,456 200,456 C164,456 130,446 116,424 Z" fill="#FFF7F9" opacity=".72"/>',
      // 两侧阴影
      '<path d="M116,424 C112,470 110,516 108,560 L140,560 C138,506 140,456 148,424 Z" fill="' + c.collar + '" opacity=".12"/>',
      '<path d="M284,424 C288,470 290,516 292,560 L260,560 C262,506 260,456 252,424 Z" fill="' + c.collar + '" opacity=".12"/>',
      // 泡泡袖
      '<path d="M136,392 C110,398 94,424 96,452 C98,474 116,482 130,466 C142,450 146,410 146,394 Z" fill="#FFFCFA" stroke="#F6DEE7" stroke-width="1.6"/>',
      '<path d="M264,392 C290,398 306,424 304,452 C302,474 284,482 270,466 C258,450 254,410 254,394 Z" fill="#FFFCFA" stroke="#F6DEE7" stroke-width="1.6"/>',
      // 袖口
      '<path d="M97,456 C102,476 118,480 130,468" stroke="' + c.collar + '" stroke-width="9" fill="none" stroke-linecap="round"/>',
      '<path d="M303,456 C298,476 282,480 270,468" stroke="' + c.collar + '" stroke-width="9" fill="none" stroke-linecap="round"/>',
      // 手臂
      '<path d="M94,470 C88,500 92,530 100,556 L126,556 C120,524 118,494 122,472 Z" fill="url(#skin-' + c.id + ')" stroke="#F0C6BE" stroke-width="1.4"/>',
      '<path d="M306,470 C312,500 308,530 300,556 L274,556 C280,524 282,494 278,472 Z" fill="url(#skin-' + c.id + ')" stroke="#F0C6BE" stroke-width="1.4"/>',
      // 水手领
      '<path d="M200,344 L268,364 L276,432 L200,400 L124,432 L132,364 Z" fill="' + c.collar + '"/>',
      '<path d="M200,346 L240,358 L200,408 L160,358 Z" fill="url(#skin-' + c.id + ')"/>',
      '<path d="M200,344 L268,364 L270,378 L200,360 L130,378 L132,364 Z" fill="#FFFFFF" opacity=".52"/>',
      '<path d="M200,346 L240,358 L200,408 L160,358 Z" stroke="#F6DEE7" stroke-width="1.2" fill="none" opacity=".7"/>',
      // 胸前蝴蝶结
      '<path d="M200,404 L170,386 L164,414 L200,420 Z" fill="' + c.ribbon + '"/>',
      '<path d="M200,404 L230,386 L236,414 L200,420 Z" fill="' + c.ribbon + '"/>',
      '<path d="M196,418 L184,448 L196,442 L204,452 L208,418 Z" fill="' + c.ribbonDark + '"/>',
      '<circle cx="200" cy="410" r="9" fill="' + c.ribbonDark + '"/>',
      '<circle cx="197" cy="407" r="3" fill="#FFFFFF" opacity=".72"/>',
      // 腰部接缝与布料褶
      '<path d="M120,506 C160,522 240,522 280,506" stroke="' + c.collar + '" stroke-width="2" opacity=".28" fill="none"/>',
      '<path d="M150,520 L146,560 M182,516 L180,560 M214,516 L216,560 M246,520 L250,560" stroke="' + c.collar + '" stroke-width="2" opacity=".22" fill="none"/>',
      '</g>'
    ].join('');
  }

  function charSVG(id) {
    const c = CHAR_MAP[id] || CHARS[0];
    const moods = ['neutral', 'happy', 'sad'];
    // 静态立绘作为 Live2D 加载失败时的回退；正常时由 canvas 覆盖显示
    return '<div class="chara-svg chara-raster chara-body chara-live2d" role="img" aria-label="' + c.name + '立绘">'
      + '<div class="chara-fallback">'
      + '<div class="chara-breathe">'
      + moods.map(function (m) {
        const file = m === 'neutral' ? c.id + '_full.png' : c.id + '_full_' + m + '.png';
        return '<img class="ci ci-' + m + '" src="assets/chara/' + file + '" alt="" draggable="false">';
      }).join('')
      + '</div></div>'
      + '<canvas class="chara-live2d-canvas" data-live2d-char="' + c.id + '" aria-hidden="true"></canvas>'
      + '<span class="chara-mood-badge" aria-hidden="true"></span>'
      + '</div>';
  }

  function miniAvatar(id) {
    const c = CHAR_MAP[id] || CHARS[0];
    return '<img class="mini-ava" src="assets/chara/' + c.id + '_ava.png" alt="' + c.name + '" draggable="false">';
  }

  /* ------------------------------------------------------------ 台词库 --- */

  const LINES = {
    sakura: {
      greet: [
        '主人~换我值班啦！今天也要把坏网站都赶走哦～',
        '嘻嘻，小樱上线！可疑的网址统统交给我！',
        '主人主人！有我在，坏网站不敢靠近你的～'
      ],
      safe: [
        '主人~这个网站看起来没有问题哦！放心点吧～',
        '检测完毕！安全！主人可以安心啦～',
        '耶！这次是个好网站，我给它打满分～'
      ],
      warn: [
        '唔姆…这个网站有点可疑诶，主人要小心一点哦！',
        '呜…我总觉得哪里怪怪的，主人先别急着输密码！',
        '有一点点危险的味道…主人先看看下面的原因吧～'
      ],
      danger: [
        '主人！这个网站超——危险的！绝对不要点！',
        '呜哇！是坏坏的钓鱼网站！主人快离它远一点！',
        '危险危险危险！我已经帮主人把它拦下来啦！'
      ],
      error: [
        '诶？主人输入的东西好像不是一个网址呢…',
        '这个…我看不懂诶，主人再检查一下格式好不好？',
        '呜…好像打错字了，再试一次吧主人～'
      ],
      thinking: ['让我看看…嗯嗯…', '正在翻可疑名单…等我一下下～', '嗅嗅…这个网址有点味道…']
    },
    mint: {
      greet: [
        '我是薄荷。接下来由我负责这次检测，请放心。',
        '已切换到薄荷。我会尽量把风险讲清楚。',
        '你好，我是薄荷。检测依据共 12 项特征，结果会逐条列出。'
      ],
      safe: [
        '根据分析，这个 URL 没有命中高风险特征，可以正常访问。',
        '检测完成。风险分数很低，属于安全范围。',
        '结论是安全。不过涉及支付时，仍建议确认域名拼写。'
      ],
      warn: [
        '根据分析，这个 URL 的风险等级为中等，请小心。',
        '有几项特征值得注意，建议不要在该页面输入敏感信息。',
        '风险可控但不确定。请先核对域名主体再决定是否继续。'
      ],
      danger: [
        '这个 URL 命中多项高危特征，建议立即终止访问。',
        '结论是危险。请不要在该页面输入账号、密码或支付信息。',
        '检测到明显的仿冒结构，这是一条高风险链接。'
      ],
      error: [
        '输入内容无法解析为标准 URL，请检查协议与域名格式。',
        '解析失败。请确认地址没有多余空格，且以 http 或 https 开头。'
      ],
      thinking: ['正在逐项核对特征…', '分析中，请稍候。', '正在计算风险权重…']
    },
    sky: {
      greet: [
        '那、那个…我也可以帮忙检测的…请多指教…',
        '呜…换我了…我会认真看的…',
        '我、我叫天蓝…有可疑的网址就交给我吧…'
      ],
      safe: [
        '那个…我检测完了，这个网站是安全的哦…',
        '嗯…没有发现问题…可以放心点开…',
        '是安全的…我把 12 项都看过了…'
      ],
      warn: [
        '那个…好像有点不对劲…要不要再确认一下…',
        '我、我不太确定…但建议先不要填个人信息…',
        '呜…有几项看起来怪怪的…请小心一点…'
      ],
      danger: [
        '对、对不起…这个网站很危险…请千万不要打开…',
        '呜…它好像在骗人…快关掉吧…',
        '这个真的很危险…我、我帮主人挡住了…'
      ],
      error: [
        '呜…这个好像不是网址…能再检查一下吗…',
        '对、对不起…我解析不了…是不是少打了什么…'
      ],
      thinking: ['我、我在看…等一下下…', '呜…让我仔细检查…', '正在比对域名…']
    }
  };

  const CHAT_TOPICS = [
    {
      keys: ['是什么', '什么是', '钓鱼', 'phishing', '骗'],
      q: '什么是钓鱼网站？',
      a: {
        sakura: '钓鱼网站会装成银行、购物网站或者登录页，骗主人输入账号密码！它们的网址通常和真的只差一两个字母，超坏的！',
        mint: '钓鱼网站通过仿冒可信站点诱导用户提交凭据。识别要点是核对域名主体，而不是页面外观。',
        sky: '它们…会做得和真网站一模一样…但是网址不一样…输入密码就糟了…'
      }
    },
    {
      keys: ['分数', '评分', '怎么算', '多少分', '标准'],
      q: '分数是怎么算的？',
      a: {
        sakura: '12 项检查每命中一项就加分！危险项加 30 分，可疑项加 15 分，加满 100 就到顶啦～0 到 30 是安全，31 到 60 是可疑，61 以上就是危险！',
        mint: '总分由 12 项特征的加权结果相加得出，危险项 30 分，可疑项 15 分，上限 100。分数是风险权重之和，不是被攻击概率。',
        sky: '就是…每发现一个可疑的地方就加分…分数越高越危险…超过 60 分我就很担心了…'
      }
    },
    {
      keys: ['https', '证书', '加密', '小锁'],
      q: '有 HTTPS 就一定安全吗？',
      a: {
        sakura: '不是哦！https 只说明路上有加密封着，但坏人也买得起证书呀～还是要看域名是不是官方的！',
        mint: 'HTTPS 只保证传输加密，不证明站点身份。大量钓鱼站同样部署了免费证书，因此仍需核验域名。',
        sky: '那个小锁…只能说明连接是加密的…不能说明网站是好人…'
      }
    },
    {
      keys: ['域名', '网址', '怎么看', '判断'],
      q: '域名要怎么判断？',
      a: {
        sakura: '主人记住：看最后两段！xxx.taobao.com 才是淘宝的；如果是 taobao.xxx.com，那 xxx 才是真正的主人哦！',
        mint: '从右往左读取域名层级，主体通常由最后两段构成。taobao.com.example.xyz 的真实主体是 example.xyz，而非 taobao.com。',
        sky: '看…看最后面的部分…前面的都可以随便写…'
      }
    },
    {
      keys: ['你', '名字', '谁', '介绍'],
      q: '你是谁呀？',
      a: {
        sakura: '我是小樱！PhishGuard 的元气看板娘～负责帮主人赶走坏网站！',
        mint: '我是薄荷，负责检测与说明。相比口号，我更愿意把每一项依据讲清楚。',
        sky: '我、我是天蓝…有点害羞…但是检测的时候很认真的…'
      }
    },
    {
      keys: ['记录', '隐私', '上传', '数据', '安全吗'],
      q: '我的数据会被上传吗？',
      a: {
        sakura: '不会不会！所有检测都在主人的浏览器里完成，历史记录也只存在本地～',
        mint: '全部计算在本地执行，不发起网络请求。历史记录保存在浏览器存储中，可随时清空。',
        sky: '没有上传…真的…只在你自己的电脑里…'
      }
    }
  ];

  function pick(arr, seed) {
    if (!arr || !arr.length) return '';
    const i = typeof seed === 'number' ? seed % arr.length : Math.floor(Math.random() * arr.length);
    return arr[i];
  }

  function lineFor(charId, kind) {
    const set = LINES[charId] || LINES.sakura;
    return pick(set[kind] || set.greet);
  }

  function chatReply(charId, text) {
    const t = String(text || '').toLowerCase();
    const hit = CHAT_TOPICS.find(function (topic) {
      return topic.keys.some(function (k) { return t.indexOf(k) !== -1; });
    });
    if (hit) return hit.a[charId] || hit.a.sakura;
    const fallback = {
      sakura: '唔…这个问题我还没学会诶。不过主人可以输入一个网址，我马上帮你检测！',
      mint: '这个问题超出我的检测范围。你可以把网址发给我，我会逐项给出风险依据。',
      sky: '对、对不起…我不太懂这个…但是检测网址我会的…'
    };
    return fallback[charId] || fallback.sakura;
  }

  /* ---------------------------------------------------------- 本地存储 --- */

  const Store = {
    KEY: 'phishguard.history.v1',
    MAX: 40,
    backend: null,          // 由各端注入：{get(), set(list)}
    async load() {
      try {
        const raw = this.backend ? await this.backend.get() : null;
        const list = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.list) ? raw.list : []);
        return list.filter(function (x) { return x && typeof x.url === 'string'; }).slice(0, this.MAX);
      } catch (e) { return []; }
    },
    async save(list) {
      try { if (this.backend) await this.backend.set(list.slice(0, this.MAX)); } catch (e) { /* 存储不可用时静默降级 */ }
    },
    async add(entry) {
      const list = await this.load();
      list.unshift(entry);
      const next = list.slice(0, this.MAX);
      await this.save(next);
      return next;
    },
    async remove(url, time) {
      const list = await this.load();
      const next = list.filter(function (x) { return !(x.url === url && x.time === time); });
      await this.save(next);
      return next;
    },
    async clear() { await this.save([]); return []; }
  };

  /* -------------------------------------------------------------- 导出 --- */

  root.PhishGuard = {
    analyze: analyze,
    levelMeta: levelMeta,
    CHARS: CHARS,
    CHAR_MAP: CHAR_MAP,
    charSVG: charSVG,
    miniAvatar: miniAvatar,
    LINES: LINES,
    lineFor: lineFor,
    chatReply: chatReply,
    CHAT_TOPICS: CHAT_TOPICS,
    Store: Store,
    LEVEL_META: LEVEL_META
  };
})(typeof window !== 'undefined' ? window : this);

/* ============================================================================
 * PhishGuard · 通用 UI 工具（主题 / 花瓣 / 评分环 / 音效 / 历史行）
 * 网页版与插件版共用同一套实现，仅主题与存储的落点不同。
 * ========================================================================== */
(function (root) {
  'use strict';

  const PG = root.PhishGuard;
  const UI = {};
  const CIRC = 2 * Math.PI * 60; // 评分环周长（r = 60）

  UI.$ = function (sel, scope) { return (scope || document).querySelector(sel); };
  UI.$$ = function (sel, scope) { return Array.prototype.slice.call((scope || document).querySelectorAll(sel)); };

  /* ------------------------------------------------------------ 主题 --- */
  UI.themeBackend = {
    get: function () {
      try { return localStorage.getItem('phishguard.theme'); } catch (e) { return null; }
    },
    set: function (v) {
      try { localStorage.setItem('phishguard.theme', v); } catch (e) { /* 忽略 */ }
    }
  };

  UI.applyTheme = function (name, persist) {
    const theme = ['pink', 'mint', 'sky'].indexOf(name) !== -1 ? name : 'pink';
    document.documentElement.setAttribute('data-theme', theme);
    UI.$$('[data-set-theme]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-set-theme') === theme));
    });
    if (persist !== false) {
      try {
        const r = UI.themeBackend.set(theme);
        if (r && typeof r.then === 'function') r.catch(function () {});
      } catch (e) { /* 忽略 */ }
    }
  };

  UI.initTheme = async function () {
    let saved = null;
    try { saved = await UI.themeBackend.get(); } catch (e) { saved = null; }
    if (saved && typeof saved === 'object' && saved.theme) saved = saved.theme;
    UI.applyTheme(saved || 'pink', false);
  };

  /* ------------------------------------------------------------ 花瓣 --- */
  UI.spawnPetals = function (host, count) {
    if (!host || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const frag = document.createDocumentFragment();
    for (let i = 0; i < count; i++) {
      const p = document.createElement('span');
      const cls = i % 7 === 0 ? 'petal p2' : (i % 11 === 0 ? 'petal p3' : 'petal');
      p.className = cls;
      p.style.setProperty('--x', (Math.random() * 100).toFixed(2) + '%');
      p.style.setProperty('--s', (7 + Math.random() * 8).toFixed(1) + 'px');
      p.style.setProperty('--dur', (11 + Math.random() * 12).toFixed(1) + 's');
      p.style.setProperty('--delay', (Math.random() * 14).toFixed(1) + 's');
      p.style.setProperty('--drift', (Math.random() * 90 - 45).toFixed(0) + 'px');
      frag.appendChild(p);
    }
    host.appendChild(frag);
  };

  /* ---------------------------------------------------------- 评分环 --- */
  UI.ringSet = function (svg, score, level) {
    if (!svg) return;
    const fill = svg.querySelector('.ring-fill');
    if (!fill) return;
    svg.setAttribute('data-level', level);
    const grad = { safe: 'ringSafe', warn: 'ringWarn', danger: 'ringDanger', idle: 'ringIdle' }[level] || 'ringIdle';
    fill.setAttribute('stroke', 'url(#' + grad + ')');
    const target = CIRC * (1 - Math.max(0, Math.min(100, score)) / 100);
    // 先重置再赋值，强制回流后直接写入终值：CSS transition 会从起点动画到终点。
    // 这里不使用 requestAnimationFrame，避免标签页在后台时动画不触发、数值停在起点。
    fill.style.transition = 'none';
    fill.style.strokeDashoffset = String(CIRC);
    void fill.getBoundingClientRect();
    fill.style.transition = '';
    fill.style.strokeDashoffset = String(target);
  };

  UI.countUp = function (el, to, dur) {
    if (!el) return;
    const dest = Math.round(to);
    const time = dur || 900;
    // 先落终值，保证任何情况下数字都是对的；动画只是额外效果
    el.textContent = String(dest);
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    el.textContent = '0';
    const start = performance.now();
    let finished = false;
    function tick(now) {
      if (finished) return;
      // 某些环境下 rAF 的时间戳可能早于 start，必须夹紧，否则会出现负数
      const p = Math.min(1, Math.max(0, (now - start) / time));
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = String(Math.round(dest * eased));
      if (p < 1) requestAnimationFrame(tick);
      else { finished = true; el.textContent = String(dest); }
    }
    requestAnimationFrame(tick);
    setTimeout(function () {
      if (!finished) { finished = true; el.textContent = String(dest); }
    }, time + 150);
  };

  /* ------------------------------------------------------------ 音效 --- */
  let audioCtx = null;
  UI.chime = function (level, enabled) {
    if (!enabled) return;
    try {
      const Ctx = root.AudioContext || root.webkitAudioContext;
      if (!Ctx) return;
      audioCtx = audioCtx || new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const seq = level === 'safe' ? [784, 1046]
        : level === 'warn' ? [659, 880]
        : [523, 440];
      seq.forEach(function (freq, i) {
        const t0 = audioCtx.currentTime + i * 0.17;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t0);
        gain.gain.setValueAtTime(0, t0);
        gain.gain.linearRampToValueAtTime(level === 'danger' ? 0.16 : 0.13, t0 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.42);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(t0);
        osc.stop(t0 + 0.45);
      });
    } catch (e) { /* 浏览器不允许时静默 */ }
  };

  /* ------------------------------------------------------------ 工具 --- */
  UI.esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  UI.shortUrl = function (url, max) {
    const limit = max || 46;
    const s = String(url || '');
    return s.length > limit ? s.slice(0, limit - 1) + '…' : s;
  };

  UI.timeLabel = function (ts) {
    try {
      const d = new Date(ts);
      const pad = function (n) { return n < 10 ? '0' + n : String(n); };
      return pad(d.getHours()) + ':' + pad(d.getMinutes());
    } catch (e) { return '--:--'; }
  };

  UI.dayLabel = function (ts) {
    const d = new Date(ts);
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    return (sameDay ? '今天 ' : '') + UI.timeLabel(ts);
  };

  /* -------------------------------------------------------- 复用片段 --- */
  UI.charButton = function (c, active) {
    return '<button type="button" class="char-btn" data-char="' + c.id + '" aria-pressed="' + (active ? 'true' : 'false') + '" title="切换到' + c.name + '">'
      + PG.miniAvatar(c.id) + '<span>' + c.name + '</span></button>';
  };

  UI.historyRow = function (item, opts) {
    const meta = PG.levelMeta(item.level);
    return '<div class="hrow" data-level="' + item.level + '" data-url="' + UI.esc(item.url) + '" data-time="' + item.time + '">'
      + '<span class="score">' + item.score + '</span>'
      + '<span class="badge">' + meta.label + '</span>'
      + '<span class="url" title="' + UI.esc(item.url) + '">' + UI.esc(item.url) + '</span>'
      + (opts && opts.hideTime ? '' : '<span class="time">' + UI.timeLabel(item.time) + '</span>')
      + '<button type="button" class="del" aria-label="删除这条记录" title="删除">×</button>'
      + '</div>';
  };

  UI.petalHost = function () {
    let host = document.querySelector('.petals');
    if (!host) {
      host = document.createElement('div');
      host.className = 'petals';
      const bg = document.querySelector('.bg') || document.body;
      bg.appendChild(host);
    }
    return host;
  };

  root.PGUI = UI;
})(typeof window !== 'undefined' ? window : this);

/* ============================================================================
 * PhishGuard · 浏览器插件弹窗交互（Chromium / Firefox 共用）
 * 兼容层：所有 chrome.* / browser.* 调用统一走 browserAPI。
 * ========================================================================== */
(function () {
  'use strict';

  const browserAPI = (typeof browser !== 'undefined') ? browser : chrome;

  const PG = window.PhishGuard;
  const UI = window.PGUI;
  const $ = UI.$;
  const $$ = UI.$$;

  const state = {
    char: 'sakura',
    sound: false,
    busy: false,
    last: null,
    history: [],
    expanded: false,
    clearArmed: false,
    mood: 'idle'
  };

  const el = {};
  function cacheDom() {
    [
      'urlInput', 'detectBtn', 'detectBar', 'resultCard', 'scoreRing', 'scoreNum',
      'resultTitle', 'levelText', 'levelPill', 'stampMini', 'popWho', 'popLine',
      'popReasons', 'popAll', 'popAllText', 'popHistoryList', 'popHistoryCount',
      'popClear', 'popSwitch', 'popCharaStage', 'popTip', 'useTab',
      'soundBtn', 'aboutBtn', 'aboutModal', 'aboutClose'
    ].forEach(function (id) { el[id] = document.getElementById(id); });
  }

  /* -------------------------------------------------------------- 偏好 --- */
  const prefs = {
    async get(key, fallback) {
      try {
        const obj = await browserAPI.storage.local.get(key);
        return obj && obj[key] != null ? obj[key] : fallback;
      } catch (e) { return fallback; }
    },
    set(key, value) {
      try { browserAPI.storage.local.set({ [key]: value }); } catch (e) { /* 忽略 */ }
    }
  };

  /* ------------------------------------------------------------ 基础 UI --- */
  const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  function setBusy(busy) {
    state.busy = busy;
    el.detectBtn.disabled = busy;
    el.detectBtn.querySelector('.btn-label').textContent = busy ? '分析中' : '检测';
    el.detectBtn.querySelector('.spark').textContent = busy ? '·' : '✨';
  }

  function setMood(mood) {
    state.mood = mood;
    el.resultCard.setAttribute('data-mood', mood);
    if (window.PhishGuardLive2D) window.PhishGuardLive2D.setMood(mood);
  }

  function say(text) {
    el.popLine.textContent = text;
  }

  /* ---------------------------------------------------------- 看板娘切换 --- */
  function renderSwitch() {
    el.popSwitch.innerHTML = PG.CHARS.map(function (c) {
      return UI.charButton(c, c.id === state.char);
    }).join('');
    el.popSwitch.addEventListener('click', function (e) {
      const btn = e.target.closest('.char-btn');
      if (!btn || btn.getAttribute('data-char') === state.char) return;
      setChar(btn.getAttribute('data-char'), true);
    });
  }

  function setChar(id, speak) {
    const c = PG.CHAR_MAP[id] || PG.CHARS[0];
    state.char = c.id;

    if (window.PhishGuardLive2D) window.PhishGuardLive2D.disposeIn(el.popCharaStage);
    el.popCharaStage.innerHTML = PG.charSVG(c.id);
    const svg = el.popCharaStage.querySelector('.chara-svg');
    if (svg && !matchMedia('(prefers-reduced-motion: reduce)').matches) svg.classList.add('swap');
    if (window.PhishGuardLive2D) {
      const kind = state.last ? (state.last.level === 'safe' ? 'happy' : (state.last.level === 'warn' ? 'warn' : 'danger')) : 'idle';
      window.PhishGuardLive2D.mountIn(el.popCharaStage, c.id, kind);
    }

    el.popWho.textContent = c.name;
    UI.$$('.char-btn').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-char') === c.id));
    });

    if (state.last) {
      const kind = state.last.level === 'safe' ? 'safe' : (state.last.level === 'warn' ? 'warn' : 'danger');
      setMood(kind === 'safe' ? 'happy' : kind);
      say(PG.lineFor(c.id, kind));
    } else if (speak) {
      setMood('idle');
      say(PG.lineFor(c.id, 'greet'));
    }

    prefs.set('phishguard.char', c.id);
  }

  /* ------------------------------------------------------------ 结果渲染 --- */
  const TITLE = { safe: '看起来很安全', warn: '有点可疑', danger: '很危险！' };

  function reasonHTML(r) {
    const sev = r.status === 'danger' ? 'danger' : 'warn';
    return '<div class="reason-item" data-sev="' + sev + '">'
      + '<span class="sev">' + (sev === 'danger' ? '!' : '?') + '</span>'
      + '<div class="txt"><div class="title-row"><b>' + UI.esc(r.title) + '</b>'
      + '<span class="weight">+' + r.weight + '</span></div>'
      + '<p>' + UI.esc(r.detail) + '</p></div></div>';
  }

  function checksHTML(results) {
    return results.map(function (r) {
      const mark = r.status === 'safe' ? '✓' : (r.status === 'danger' ? '!' : (r.status === 'warn' ? '?' : '·'));
      const st = r.status === 'safe' ? '通过' : (r.status === 'danger' ? '危险' : (r.status === 'warn' ? '可疑' : '—'));
      return '<div class="check-row" data-st="' + r.status + '">'
        + '<span class="mark">' + mark + '</span>'
        + '<span class="nm">' + UI.esc(r.title) + '</span>'
        + '<span class="st">' + st + '</span></div>';
    }).join('');
  }

  function renderReasons(res) {
    if (state.expanded && res) {
      el.popReasons.innerHTML = checksHTML(res.results);
      el.popAllText.textContent = '收起检测项';
      return;
    }
    if (!res) {
      el.popReasons.innerHTML = '<div class="pop-empty"><span class="big">0</span><span>还没有检测结果</span></div>';
      el.popAllText.textContent = '查看 12 项检测规则';
      return;
    }
    if (res.hits.length === 0) {
      el.popReasons.innerHTML = '<div class="reason-item" data-sev="safe">'
        + '<span class="sev">✓</span><div class="txt"><div class="title-row"><b>全部通过</b></div>'
        + '<p>12 项特征都没有命中，可以放心访问。</p></div></div>';
    } else {
      el.popReasons.innerHTML = res.hits.map(reasonHTML).join('');
    }
    el.popAllText.textContent = '查看全部 12 项';
  }

  function renderResult(res) {
    state.last = res;
    state.expanded = false;
    const meta = PG.levelMeta(res.level);

    el.resultCard.setAttribute('data-level', res.level);
    if (el.stampMini) el.stampMini.textContent = meta.label;
    el.resultTitle.textContent = TITLE[res.level];
    el.levelText.textContent = meta.label + ' ' + res.score + ' 分';
    UI.ringSet(el.scoreRing, res.score, res.level);
    UI.countUp(el.scoreNum, res.score, 700);

    renderReasons(res);

    const kind = res.level === 'safe' ? 'safe' : (res.level === 'warn' ? 'warn' : 'danger');
    setMood(kind === 'safe' ? 'happy' : kind);
    say(PG.lineFor(state.char, kind));
    UI.chime(res.level, state.sound);

    saveResult(res).then(renderHistory);
  }

  function renderError(msg) {
    state.last = null;
    state.expanded = false;
    el.resultCard.setAttribute('data-level', 'idle');
    if (el.stampMini) el.stampMini.textContent = '待机';
    el.resultTitle.textContent = '格式不对';
    el.levelText.textContent = '等待检测';
    UI.ringSet(el.scoreRing, 0, 'idle');
    UI.countUp(el.scoreNum, 0, 400);
    el.popReasons.innerHTML = '<div class="pop-empty"><span class="big">?</span><span>' + UI.esc(msg) + '</span></div>';
    el.popAllText.textContent = '查看 12 项检测规则';
    setMood('idle');
    say(PG.lineFor(state.char, 'error'));
    el.detectBar.classList.remove('anim-shake');
    void el.detectBar.offsetWidth;
    el.detectBar.classList.add('anim-shake');
  }

  /* -------------------------------------------------------------- 检测 --- */
  async function detect() {
    if (state.busy) return;
    const raw = (el.urlInput.value || '').trim();
    if (!raw) {
      say('先输入一个网址哦～');
      el.urlInput.focus();
      return;
    }
    const res = PG.analyze(raw);
    if (!res.ok) { renderError(res.error); return; }

    setBusy(true);
    setMood('thinking');
    say(PG.lineFor(state.char, 'thinking'));
    await sleep(620);
    setBusy(false);
    renderResult(res);
  }

  async function detectCurrentTab() {
    try {
      const tabs = await browserAPI.tabs.query({ active: true, currentWindow: true });
      const tab = tabs && tabs[0];
      if (!tab || !tab.url || !/^https?:/i.test(tab.url)) {
        el.popTip.textContent = '当前页面不是网页地址';
        return false;
      }
      el.urlInput.value = tab.url;
      await detect();
      return true;
    } catch (e) {
      el.popTip.textContent = '无法读取当前标签页';
      return false;
    }
  }

  /* ------------------------------------------------------------ 历史记录 --- */
  function renderHistory() {
    el.popHistoryCount.textContent = String(state.history.length);
    el.popClear.textContent = state.clearArmed ? '确认?' : '清空';
    if (!state.history.length) {
      el.popHistoryList.innerHTML = '<div class="pop-history-empty">还没有记录</div>';
      return;
    }
    el.popHistoryList.innerHTML = state.history.slice(0, 2).map(function (item) {
      return UI.historyRow(item, { hideTime: true });
    }).join('');
  }

  async function saveResult(res) {
    state.history = await PG.Store.add({ url: res.url, score: res.score, level: res.level, time: Date.now() });
  }

  function bindHistory() {
    el.popHistoryList.addEventListener('click', async function (e) {
      const row = e.target.closest('.hrow');
      if (!row) return;
      if (e.target.closest('.del')) {
        state.history = await PG.Store.remove(row.getAttribute('data-url'), Number(row.getAttribute('data-time')));
        renderHistory();
        return;
      }
      el.urlInput.value = row.getAttribute('data-url');
      el.urlInput.focus();
    });

    el.popClear.addEventListener('click', async function () {
      if (!state.history.length) return;
      if (!state.clearArmed) {
        state.clearArmed = true;
        renderHistory();
        setTimeout(function () {
          if (state.clearArmed) { state.clearArmed = false; renderHistory(); }
        }, 2500);
        return;
      }
      state.clearArmed = false;
      state.history = await PG.Store.clear();
      renderHistory();
    });
  }

  /* -------------------------------------------------------------- 弹窗 --- */
  function bindModal() {
    el.aboutBtn.addEventListener('click', function () { el.aboutModal.hidden = false; });
    el.aboutClose.addEventListener('click', function () { el.aboutModal.hidden = true; });
    el.aboutModal.addEventListener('click', function (e) {
      if (e.target === el.aboutModal) el.aboutModal.hidden = true;
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') el.aboutModal.hidden = true;
    });
  }

  /* -------------------------------------------------------------- 启动 --- */
  function bindCore() {
    el.detectBtn.addEventListener('click', detect);
    el.urlInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); detect(); }
    });
    el.useTab.addEventListener('click', detectCurrentTab);

    $$('[data-set-theme]').forEach(function (b) {
      b.addEventListener('click', function () { UI.applyTheme(b.getAttribute('data-set-theme')); });
    });

    el.soundBtn.addEventListener('click', function () {
      state.sound = !state.sound;
      el.soundBtn.setAttribute('aria-pressed', String(state.sound));
      el.soundBtn.setAttribute('aria-label', state.sound ? '关闭提示音' : '开启提示音');
      prefs.set('phishguard.sound', state.sound);
      if (state.sound) UI.chime('safe', true);
    });

    el.popAll.addEventListener('click', function () {
      state.expanded = !state.expanded;
      renderReasons(state.last);
    });
  }

  async function init() {
    cacheDom();

    UI.themeBackend = {
      get: function () { return prefs.get('phishguard.theme', 'pink'); },
      set: function (v) { prefs.set('phishguard.theme', v); }
    };
    await UI.initTheme();

    UI.spawnPetals(document.querySelector('.petals'), 8);

    PG.Store.backend = {
      get: async function () {
        const obj = await browserAPI.storage.local.get(PG.Store.KEY);
        return obj && Array.isArray(obj[PG.Store.KEY]) ? obj[PG.Store.KEY] : [];
      },
      set: async function (list) {
        const payload = {};
        payload[PG.Store.KEY] = list;
        await browserAPI.storage.local.set(payload);
      }
    };

    state.sound = await prefs.get('phishguard.sound', false);
    el.soundBtn.setAttribute('aria-pressed', String(!!state.sound));

    const savedChar = await prefs.get('phishguard.char', 'sakura');
    renderSwitch();
    bindCore();
    bindHistory();
    bindModal();
    setChar(PG.CHAR_MAP[savedChar] ? savedChar : 'sakura', true);

    state.history = await PG.Store.load();
    renderHistory();

    // 打开弹窗时自动检测当前标签页，失败则保持待机
    await detectCurrentTab();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

