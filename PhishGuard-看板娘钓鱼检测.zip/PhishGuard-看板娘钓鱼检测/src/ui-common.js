/* ============================================================================
 * PhishGuard · 通用 UI 工具（主题 / 花瓣 / 评分环 / 音效 / 历史行）
 * 网页版与插件版共用同一套实现，仅主题与存储的落点不同。
 * ========================================================================== */
(function (root) {
  'use strict';

  const PG = root.PhishGuard;
  const UI = {};
  const CIRC = 2 * Math.PI * 60; // 评分环周长（r = 60）

  UI.$ = function (sel, scope) { return (scope || document).querySelector(sel); };
  UI.$$ = function (sel, scope) { return Array.prototype.slice.call((scope || document).querySelectorAll(sel)); };

  /* ------------------------------------------------------------ 主题 --- */
  UI.themeBackend = {
    get: function () {
      try { return localStorage.getItem('phishguard.theme'); } catch (e) { return null; }
    },
    set: function (v) {
      try { localStorage.setItem('phishguard.theme', v); } catch (e) { /* 忽略 */ }
    }
  };

  UI.applyTheme = function (name, persist) {
    const theme = ['pink', 'mint', 'sky'].indexOf(name) !== -1 ? name : 'pink';
    document.documentElement.setAttribute('data-theme', theme);
    UI.$$('[data-set-theme]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-set-theme') === theme));
    });
    if (persist !== false) {
      try {
        const r = UI.themeBackend.set(theme);
        if (r && typeof r.then === 'function') r.catch(function () {});
      } catch (e) { /* 忽略 */ }
    }
  };

  UI.initTheme = async function () {
    let saved = null;
    try { saved = await UI.themeBackend.get(); } catch (e) { saved = null; }
    if (saved && typeof saved === 'object' && saved.theme) saved = saved.theme;
    UI.applyTheme(saved || 'pink', false);
  };

  /* ------------------------------------------------------------ 花瓣 --- */
  UI.spawnPetals = function (host, count) {
    if (!host || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const frag = document.createDocumentFragment();
    for (let i = 0; i < count; i++) {
      const p = document.createElement('span');
      const cls = i % 7 === 0 ? 'petal p2' : (i % 11 === 0 ? 'petal p3' : 'petal');
      p.className = cls;
      p.style.setProperty('--x', (Math.random() * 100).toFixed(2) + '%');
      p.style.setProperty('--s', (7 + Math.random() * 8).toFixed(1) + 'px');
      p.style.setProperty('--dur', (11 + Math.random() * 12).toFixed(1) + 's');
      p.style.setProperty('--delay', (Math.random() * 14).toFixed(1) + 's');
      p.style.setProperty('--drift', (Math.random() * 90 - 45).toFixed(0) + 'px');
      frag.appendChild(p);
    }
    host.appendChild(frag);
  };

  /* ---------------------------------------------------------- 评分环 --- */
  UI.ringSet = function (svg, score, level) {
    if (!svg) return;
    const fill = svg.querySelector('.ring-fill');
    if (!fill) return;
    svg.setAttribute('data-level', level);
    const grad = { safe: 'ringSafe', warn: 'ringWarn', danger: 'ringDanger', idle: 'ringIdle' }[level] || 'ringIdle';
    fill.setAttribute('stroke', 'url(#' + grad + ')');
    const target = CIRC * (1 - Math.max(0, Math.min(100, score)) / 100);
    // 先重置再赋值，强制回流后直接写入终值：CSS transition 会从起点动画到终点。
    // 这里不使用 requestAnimationFrame，避免标签页在后台时动画不触发、数值停在起点。
    fill.style.transition = 'none';
    fill.style.strokeDashoffset = String(CIRC);
    void fill.getBoundingClientRect();
    fill.style.transition = '';
    fill.style.strokeDashoffset = String(target);
  };

  UI.countUp = function (el, to, dur) {
    if (!el) return;
    const dest = Math.round(to);
    const time = dur || 900;
    // 先落终值，保证任何情况下数字都是对的；动画只是额外效果
    el.textContent = String(dest);
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    el.textContent = '0';
    const start = performance.now();
    let finished = false;
    function tick(now) {
      if (finished) return;
      // 某些环境下 rAF 的时间戳可能早于 start，必须夹紧，否则会出现负数
      const p = Math.min(1, Math.max(0, (now - start) / time));
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = String(Math.round(dest * eased));
      if (p < 1) requestAnimationFrame(tick);
      else { finished = true; el.textContent = String(dest); }
    }
    requestAnimationFrame(tick);
    setTimeout(function () {
      if (!finished) { finished = true; el.textContent = String(dest); }
    }, time + 150);
  };

  /* ------------------------------------------------------------ 音效 --- */
  let audioCtx = null;
  UI.chime = function (level, enabled) {
    if (!enabled) return;
    try {
      const Ctx = root.AudioContext || root.webkitAudioContext;
      if (!Ctx) return;
      audioCtx = audioCtx || new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const seq = level === 'safe' ? [784, 1046]
        : level === 'warn' ? [659, 880]
        : [523, 440];
      seq.forEach(function (freq, i) {
        const t0 = audioCtx.currentTime + i * 0.17;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t0);
        gain.gain.setValueAtTime(0, t0);
        gain.gain.linearRampToValueAtTime(level === 'danger' ? 0.16 : 0.13, t0 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.42);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(t0);
        osc.stop(t0 + 0.45);
      });
    } catch (e) { /* 浏览器不允许时静默 */ }
  };

  /* ------------------------------------------------------------ 工具 --- */
  UI.esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  UI.shortUrl = function (url, max) {
    const limit = max || 46;
    const s = String(url || '');
    return s.length > limit ? s.slice(0, limit - 1) + '…' : s;
  };

  UI.timeLabel = function (ts) {
    try {
      const d = new Date(ts);
      const pad = function (n) { return n < 10 ? '0' + n : String(n); };
      return pad(d.getHours()) + ':' + pad(d.getMinutes());
    } catch (e) { return '--:--'; }
  };

  UI.dayLabel = function (ts) {
    const d = new Date(ts);
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    return (sameDay ? '今天 ' : '') + UI.timeLabel(ts);
  };

  /* -------------------------------------------------------- 复用片段 --- */
  UI.charButton = function (c, active) {
    return '<button type="button" class="char-btn" data-char="' + c.id + '" aria-pressed="' + (active ? 'true' : 'false') + '" title="切换到' + c.name + '">'
      + PG.miniAvatar(c.id) + '<span>' + c.name + '</span></button>';
  };

  UI.historyRow = function (item, opts) {
    const meta = PG.levelMeta(item.level);
    return '<div class="hrow" data-level="' + item.level + '" data-url="' + UI.esc(item.url) + '" data-time="' + item.time + '">'
      + '<span class="score">' + item.score + '</span>'
      + '<span class="badge">' + meta.label + '</span>'
      + '<span class="url" title="' + UI.esc(item.url) + '">' + UI.esc(item.url) + '</span>'
      + (opts && opts.hideTime ? '' : '<span class="time">' + UI.timeLabel(item.time) + '</span>')
      + '<button type="button" class="del" aria-label="删除这条记录" title="删除">×</button>'
      + '</div>';
  };

  UI.petalHost = function () {
    let host = document.querySelector('.petals');
    if (!host) {
      host = document.createElement('div');
      host.className = 'petals';
      const bg = document.querySelector('.bg') || document.body;
      bg.appendChild(host);
    }
    return host;
  };

  root.PGUI = UI;
})(typeof window !== 'undefined' ? window : this);
