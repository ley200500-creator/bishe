/* ============================================================================
 * PhishGuard · 网页版交互
 * ========================================================================== */
(function () {
  'use strict';

  const PG = window.PhishGuard;
  const UI = window.PGUI;
  const $ = UI.$;
  const $$ = UI.$$;

  const state = {
    char: 'sakura',
    sound: false,
    busy: false,
    last: null,
    history: [],
    clearArmed: false,
    chatStarted: false
  };

  const DEMO = {
    safe: 'https://www.example.com',
    warn: 'http://free-gift-2024.top//login?redirect=account&token=abc',
    danger: 'http://apple-id-verify.xyz/account/confirm?user=1234567890&token=abcdefghijklmnopqrstuvwxyz'
  };

  const el = {};
  function cacheDom() {
    [
      'urlInput', 'detectBtn', 'resultCard', 'scoreRing', 'scoreNum', 'stamp',
      'resultTitle', 'levelPill', 'levelText', 'hostLine', 'verdictLine',
      'reasonList', 'reasonsCount', 'checksToggle', 'checksToggleText', 'checksAll',
      'charaPanel', 'charaStage', 'charaName', 'charaTag', 'charaSwitch',
      'bubbleText', 'bubbleWho', 'historyList', 'historyCount', 'clearHistory',
      'chatFab', 'chatPanel', 'chatBody', 'chatChips', 'chatForm', 'chatInput',
      'chatName', 'chatAva', 'chatClose', 'aboutModal', 'aboutClose', 'aboutBtn',
      'soundBtn', 'detectBar'
    ].forEach(function (id) { el[id] = document.getElementById(id); });
    el.detectBar = document.querySelector('.detect-bar');
  }

  /* ------------------------------------------------------------ 基础 UI --- */
  const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  function say(text) {
    if (!el.bubbleText) return;
    el.bubbleText.textContent = text;
    const bubble = document.querySelector('.bubble');
    if (bubble && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      bubble.animate(
        [{ opacity: .4, transform: 'translateY(3px)' }, { opacity: 1, transform: 'none' }],
        { duration: 260, easing: 'ease-out' }
      );
    }
  }

  function setMood(mood) {
    if (el.charaPanel) el.charaPanel.setAttribute('data-mood', mood);
  }

  function setBusy(busy) {
    state.busy = busy;
    if (!el.detectBtn) return;
    el.detectBtn.disabled = busy;
    el.detectBtn.querySelector('.btn-label').textContent = busy ? '检测中…' : '开始检测！';
    el.detectBtn.querySelector('.spark').textContent = busy ? '·' : '✨';
  }

  function shakeBar() {
    if (!el.detectBar) return;
    el.detectBar.classList.remove('anim-shake');
    void el.detectBar.offsetWidth;
    el.detectBar.classList.add('anim-shake');
  }

  /* ---------------------------------------------------------- 看板娘切换 --- */
  function renderCharSwitch() {
    el.charaSwitch.innerHTML = PG.CHARS.map(function (c) {
      return UI.charButton(c, c.id === state.char);
    }).join('');
    el.charaSwitch.addEventListener('click', function (e) {
      const btn = e.target.closest('.char-btn');
      if (!btn) return;
      if (btn.getAttribute('data-char') === state.char) return;
      setChar(btn.getAttribute('data-char'), true);
    });
  }

  function setChar(id, speak) {
    const c = PG.CHAR_MAP[id] || PG.CHARS[0];
    state.char = c.id;

    el.charaStage.innerHTML = PG.charSVG(c.id);
    const svg = el.charaStage.querySelector('.chara-svg');
    if (svg && !matchMedia('(prefers-reduced-motion: reduce)').matches) svg.classList.add('swap');

    el.charaName.textContent = c.name;
    el.charaTag.textContent = c.tag;
    el.bubbleWho.textContent = c.name;
    el.chatName.textContent = c.name;
    el.chatAva.innerHTML = PG.miniAvatar(c.id);

    UI.$$('.char-btn').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-char') === c.id));
    });

    if (state.last) {
      const kind = state.last.level === 'safe' ? 'safe' : (state.last.level === 'warn' ? 'warn' : 'danger');
      setMood(kind === 'safe' ? 'happy' : kind);
      say(PG.lineFor(c.id, kind));
    } else if (speak) {
      setMood('idle');
      say(PG.lineFor(c.id, 'greet'));
    }

    try { localStorage.setItem('phishguard.char', c.id); } catch (e) { /* 忽略 */ }
  }

  /* ------------------------------------------------------------ 结果渲染 --- */
  const TITLE = {
    safe: '这个网址看起来很干净',
    warn: '有点可疑，先别急着输密码',
    danger: '危险！这很像钓鱼网址'
  };

  function renderResult(res) {
    state.last = res;
    const meta = PG.levelMeta(res.level);
    const card = el.resultCard;

    card.setAttribute('data-level', res.level);
    el.stamp.textContent = meta.label;
    el.resultTitle.innerHTML = TITLE[res.level] + '<small>' + meta.en + '</small>';

    UI.ringSet(el.scoreRing, res.score, res.level);
    UI.countUp(el.scoreNum, res.score);

    el.levelPill.style.color = '';
    el.levelText.textContent = meta.label + ' · ' + res.score + ' 分';

    el.hostLine.innerHTML = '域名 <b>' + UI.esc(res.host) + '</b> · ' + res.protocol.toUpperCase()
      + ' · 命中 <b>' + res.hits.length + '</b> 项';

    const verdict = res.level === 'safe'
      ? (res.hits.length === 0
        ? '12 项特征全部通过。涉及登录或支付时，仍建议再核对一次域名拼写。'
        : '只命中了 ' + res.hits.length + ' 项低权重特征，整体风险较低。')
      : res.level === 'warn'
        ? '命中 ' + res.hits.length + ' 项可疑特征，共 ' + res.score + ' 分。请确认域名主体后再决定是否继续。'
        : '命中 ' + res.hits.length + ' 项高危特征，共 ' + res.score + ' 分。建议立即关闭该页面。';
    el.verdictLine.textContent = verdict;

    if (res.hits.length === 0) {
      el.reasonList.innerHTML = '<div class="reason-item" data-sev="safe">'
        + '<span class="sev">✓</span>'
        + '<div class="txt"><div class="title-row"><b>没有发现风险特征</b></div>'
        + '<p>长度、协议、域名结构、品牌仿冒等 12 项检查均未命中，可以放心访问。</p></div></div>';
    } else {
      el.reasonList.innerHTML = res.hits.map(function (h) {
        const sev = h.status === 'danger' ? 'danger' : 'warn';
        return '<div class="reason-item" data-sev="' + sev + '">'
          + '<span class="sev">' + (sev === 'danger' ? '!' : '?') + '</span>'
          + '<div class="txt"><div class="title-row"><b>' + UI.esc(h.title) + '</b>'
          + '<span class="weight">+' + h.weight + '</span></div>'
          + '<p>' + UI.esc(h.detail) + '</p></div></div>';
      }).join('');
    }
    el.reasonsCount.textContent = res.hits.length
      ? '命中 ' + res.hits.length + ' 项 · 共 +' + res.score + ' 分'
      : '12 项全部通过';

    el.checksAll.innerHTML = res.results.map(function (r) {
      const mark = r.status === 'safe' ? '✓' : (r.status === 'danger' ? '!' : (r.status === 'warn' ? '?' : '·'));
      const st = r.status === 'safe' ? '通过' : (r.status === 'danger' ? '危险 +30' : (r.status === 'warn' ? '可疑 +15' : '不适用'));
      return '<div class="check-row" data-st="' + r.status + '">'
        + '<span class="mark">' + mark + '</span>'
        + '<span class="nm">' + UI.esc(r.title) + '</span>'
        + '<span class="st">' + st + '</span></div>';
    }).join('');

    // 没有命中项时直接把 12 项明细展开，填满结果卡并给出完整证据
    const autoOpen = res.hits.length === 0;
    el.checksAll.hidden = !autoOpen;
    el.checksToggle.setAttribute('aria-expanded', String(autoOpen));
    el.checksToggleText.textContent = autoOpen ? '收起检测项' : '查看全部 12 项检测';

    const kind = res.level === 'safe' ? 'safe' : (res.level === 'warn' ? 'warn' : 'danger');
    setMood(kind === 'safe' ? 'happy' : kind);
    say(PG.lineFor(state.char, kind));
    UI.chime(res.level, state.sound);

    if (res.level === 'danger') {
      el.charaPanel.classList.remove('shake');
      void el.charaPanel.offsetWidth;
      el.charaPanel.classList.add('shake');
      setTimeout(function () { el.charaPanel.classList.remove('shake'); }, 600);
    }

    saveResult(res);
  }

  function renderError(msg) {
    state.last = null;
    el.resultCard.setAttribute('data-level', 'idle');
    el.stamp.textContent = '待机';
    el.resultTitle.innerHTML = '网址格式不太对<small>重新检查一下</small>';
    UI.ringSet(el.scoreRing, 0, 'idle');
    UI.countUp(el.scoreNum, 0);
    el.levelText.textContent = '等待检测';
    el.hostLine.textContent = '没有解析出有效的域名。';
    el.verdictLine.textContent = msg;
    el.reasonList.innerHTML = '<div class="reason-empty"><span class="face">(´• ω •`)</span><span>'
      + UI.esc(msg) + '</span></div>';
    el.reasonsCount.textContent = '尚未检测';
    el.checksAll.innerHTML = '';
    setMood('idle');
    say(PG.lineFor(state.char, 'error'));
    shakeBar();
    try { el.urlInput.focus(); } catch (e) { /* 忽略 */ }
  }

  /* -------------------------------------------------------------- 检测 --- */
  async function detect() {
    if (state.busy) return;
    const raw = (el.urlInput.value || '').trim();
    if (!raw) {
      say('先输入一个网址哦～');
      shakeBar();
      el.urlInput.focus();
      return;
    }
    const res = PG.analyze(raw);
    if (!res.ok) { renderError(res.error); return; }

    setBusy(true);
    setMood('thinking');
    say(PG.lineFor(state.char, 'thinking'));
    await sleep(680);
    setBusy(false);
    renderResult(res);
  }

  /* ------------------------------------------------------------ 历史记录 --- */
  async function loadHistory() {
    state.history = await PG.Store.load();
    renderHistory();
  }

  function renderHistory() {
    el.historyCount.textContent = state.history.length + ' 条';
    el.clearHistory.textContent = state.clearArmed ? '再点一次确认清空' : '清空全部';
    if (!state.history.length) {
      el.historyList.innerHTML = '<div class="history-empty">还没有检测记录。上面输入一个网址，就会有第一条啦。</div>';
      return;
    }
    el.historyList.innerHTML = state.history.map(function (item) {
      return UI.historyRow(item);
    }).join('');
  }

  async function saveResult(res) {
    const entry = { url: res.url, score: res.score, level: res.level, time: Date.now() };
    state.history = await PG.Store.add(entry);
    renderHistory();
  }

  function bindHistory() {
    el.historyList.addEventListener('click', async function (e) {
      const del = e.target.closest('.del');
      const row = e.target.closest('.hrow');
      if (!row) return;
      if (del) {
        e.stopPropagation();
        state.history = await PG.Store.remove(row.getAttribute('data-url'), Number(row.getAttribute('data-time')));
        renderHistory();
        return;
      }
      el.urlInput.value = row.getAttribute('data-url');
      el.urlInput.focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    el.clearHistory.addEventListener('click', async function () {
      if (!state.history.length) return;
      if (!state.clearArmed) {
        state.clearArmed = true;
        renderHistory();
        setTimeout(function () {
          if (state.clearArmed) { state.clearArmed = false; renderHistory(); }
        }, 3000);
        return;
      }
      state.clearArmed = false;
      state.history = await PG.Store.clear();
      renderHistory();
    });
  }

  /* -------------------------------------------------------------- 聊天 --- */
  function appendMsg(text, mine) {
    const node = document.createElement('div');
    node.className = 'msg' + (mine ? ' me' : '');
    node.innerHTML = (mine ? '' : PG.miniAvatar(state.char))
      + '<div class="bubble-mini">' + UI.esc(text) + '</div>';
    el.chatBody.appendChild(node);
    el.chatBody.scrollTop = el.chatBody.scrollHeight;
  }

  function replyTo(text) {
    appendMsg(text, true);
    setTimeout(function () {
      appendMsg(PG.chatReply(state.char, text), false);
    }, 420);
  }

  function openChat() {
    el.chatPanel.hidden = false;
    el.chatFab.setAttribute('aria-expanded', 'true');
    if (!state.chatStarted) {
      state.chatStarted = true;
      appendMsg(PG.lineFor(state.char, 'greet'), false);
      appendMsg('可以用下面的问题试试，或者直接问我也行～', false);
    }
    el.chatInput.focus();
  }

  function closeChat() {
    el.chatPanel.hidden = true;
    el.chatFab.setAttribute('aria-expanded', 'false');
  }

  function bindChat() {
    el.chatFab.addEventListener('click', function () {
      if (el.chatPanel.hidden) openChat(); else closeChat();
    });
    el.chatClose.addEventListener('click', closeChat);
    el.chatForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const text = (el.chatInput.value || '').trim();
      if (!text) return;
      el.chatInput.value = '';
      replyTo(text);
    });
    el.chatChips.innerHTML = PG.CHAT_TOPICS.map(function (t) {
      return '<button type="button" data-q="' + UI.esc(t.q) + '">' + UI.esc(t.q) + '</button>';
    }).join('');
    el.chatChips.addEventListener('click', function (e) {
      const chip = e.target.closest('button[data-q]');
      if (!chip) return;
      replyTo(chip.getAttribute('data-q'));
    });
  }

  /* -------------------------------------------------------------- 弹窗 --- */
  function openAbout() { el.aboutModal.hidden = false; el.aboutClose.focus(); }
  function closeAbout() { el.aboutModal.hidden = true; el.aboutBtn.focus(); }

  function bindModal() {
    el.aboutBtn.addEventListener('click', openAbout);
    el.aboutClose.addEventListener('click', closeAbout);
    el.aboutModal.addEventListener('click', function (e) {
      if (e.target === el.aboutModal) closeAbout();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        if (!el.aboutModal.hidden) closeAbout();
        if (!el.chatPanel.hidden) closeChat();
      }
    });
  }

  /* -------------------------------------------------------------- 启动 --- */
  function bindCore() {
    el.detectBtn.addEventListener('click', detect);
    el.urlInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); detect(); }
    });

    $$('[data-demo]').forEach(function (b) {
      b.addEventListener('click', function () {
        el.urlInput.value = DEMO[b.getAttribute('data-demo')] || '';
        detect();
      });
    });

    $$('[data-set-theme]').forEach(function (b) {
      b.addEventListener('click', function () { UI.applyTheme(b.getAttribute('data-set-theme')); });
    });

    el.soundBtn.addEventListener('click', function () {
      state.sound = !state.sound;
      el.soundBtn.setAttribute('aria-pressed', String(state.sound));
      el.soundBtn.setAttribute('aria-label', state.sound ? '关闭提示音' : '开启提示音');
      try { localStorage.setItem('phishguard.sound', state.sound ? '1' : '0'); } catch (e) { /* 忽略 */ }
      if (state.sound) UI.chime('safe', true);
    });

    el.checksToggle.addEventListener('click', function () {
      const open = el.checksAll.hidden;
      el.checksAll.hidden = !open;
      el.checksToggle.setAttribute('aria-expanded', String(open));
      el.checksToggleText.textContent = open ? '收起检测项' : '查看全部 12 项检测';
    });
  }

  async function init() {
    cacheDom();
    await UI.initTheme();

    UI.spawnPetals(document.querySelector('.petals'), 16);

    state.sound = (function () {
      try { return localStorage.getItem('phishguard.sound') === '1'; } catch (e) { return false; }
    })();
    el.soundBtn.setAttribute('aria-pressed', String(state.sound));

    // 历史记录落点：localStorage
    PG.Store.backend = {
      get: function () {
        try {
          const raw = localStorage.getItem(PG.Store.KEY);
          return raw ? JSON.parse(raw) : [];
        } catch (e) { return []; }
      },
      set: function (list) {
        try { localStorage.setItem(PG.Store.KEY, JSON.stringify(list)); } catch (e) { /* 忽略 */ }
      }
    };

    let savedChar = null;
    try { savedChar = localStorage.getItem('phishguard.char'); } catch (e) { savedChar = null; }
    renderCharSwitch();

    bindCore();
    bindHistory();
    bindChat();
    bindModal();

    setChar(PG.CHAR_MAP[savedChar] ? savedChar : 'sakura', true);
    await loadHistory();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
