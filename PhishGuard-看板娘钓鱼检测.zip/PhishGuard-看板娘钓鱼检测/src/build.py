#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 src 下的源文件拼装成网页版与插件版产物（在本目录执行 python3 build.py）。"""
import os
import shutil
import urllib.parse

BUILD = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.dirname(BUILD)
EXT = os.path.join(OUT, 'extension')

def read(name):
    with open(os.path.join(BUILD, name), 'r', encoding='utf-8') as f:
        return f.read()

CORE = read('core.js')
COMMON = read('ui-common.js')
WEB = read('web.js')
POP = read('popup.js')
CSS = read('style.css')
WEB_BODY = read('web-body.html')
POP_BODY = read('popup-body.html')

FAVICON = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">'
    '<rect width="32" height="32" rx="8" fill="#FFF1F6"/>'
    '<path d="M16 3.5 L25.5 7v9.2c0 5.9-3.8 10.8-9.5 13.6C10.3 25 6.5 20.1 6.5 14.2V7z" fill="#fff" stroke="#F4789A" stroke-width="1.9"/>'
    '<path d="M11.2 15.8l3.1 3.4 6.6-7" fill="none" stroke="#F0607F" stroke-width="2.9" stroke-linecap="round" stroke-linejoin="round"/>'
    '</svg>'
)
FAVICON_URI = 'data:image/svg+xml,' + urllib.parse.quote(FAVICON, safe='')

INDEX = '''<!DOCTYPE html>
<html lang="zh-CN" data-theme="pink">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PhishGuard · 二次元看板娘钓鱼检测</title>
<meta name="description" content="PhishGuard 是一个二次元看板娘风格的钓鱼网址检测工具：12 项特征、纯前端本地分析、不上传任何数据。">
<meta name="theme-color" content="#FFF7FA">
<link rel="icon" href="%s">
<link rel="stylesheet" href="https://miaoda.feishu.cn/fonts/css2?family=Baloo+2:wght@400;600;800&family=ZCOOL+KuaiLe&family=Noto+Sans+SC:wght@400;500;700;900&display=swap">
<style>
%s
</style>
</head>
<body class="mode-web">
%s
<script>
%s
%s
%s
</script>
</body>
</html>
''' % (FAVICON_URI, CSS, WEB_BODY, CORE, COMMON, WEB)

POPUP_HTML = '''<!DOCTYPE html>
<html lang="zh-CN" data-theme="pink">
<head>
<meta charset="utf-8">
<title>PhishGuard · 看板娘安全检测</title>
<link rel="stylesheet" href="popup.css">
</head>
<body class="mode-popup">
%s
<script src="popup.js"></script>
</body>
</html>
''' % POP_BODY

POPUP_JS = '''/* PhishGuard · popup.js
 * 由 core.js + ui-common.js + popup.js 三段拼装而成，修改请回到源文件。
 */
%s
%s
%s
''' % (CORE, COMMON, POP)

os.makedirs(OUT, exist_ok=True)

with open(os.path.join(OUT, 'index.html'), 'w', encoding='utf-8') as f:
    f.write(INDEX)

# shared 目录保存唯一源文件，两个浏览器目录各放一份完全相同的副本
SHARED = os.path.join(EXT, 'shared')
os.makedirs(SHARED, exist_ok=True)
for name, content in (('popup.html', POPUP_HTML), ('popup.css', CSS), ('popup.js', POPUP_JS)):
    with open(os.path.join(SHARED, name), 'w', encoding='utf-8') as f:
        f.write(content)

for target in ('chromium', 'firefox'):
    d = os.path.join(EXT, target)
    os.makedirs(os.path.join(d, 'icons'), exist_ok=True)
    for name, content in (('popup.html', POPUP_HTML), ('popup.css', CSS), ('popup.js', POPUP_JS)):
        with open(os.path.join(d, name), 'w', encoding='utf-8') as f:
            f.write(content)

# Firefox 78–108 兼容包：单独成目录，manifest.json 直接可用
MV2 = os.path.join(EXT, 'firefox-mv2')
os.makedirs(os.path.join(MV2, 'icons'), exist_ok=True)
for name, content in (('popup.html', POPUP_HTML), ('popup.css', CSS), ('popup.js', POPUP_JS)):
    with open(os.path.join(MV2, name), 'w', encoding='utf-8') as f:
        f.write(content)
shutil.copyfile(os.path.join(BUILD, 'manifest.mv2.json'), os.path.join(MV2, 'manifest.json'))
for icon in ('icon16.png', 'icon48.png', 'icon128.png'):
    s_icon = os.path.join(EXT, 'chromium', 'icons', icon)
    if os.path.exists(s_icon):
        shutil.copyfile(s_icon, os.path.join(MV2, 'icons', icon))
for name in ('background.js',):
    s_bg = os.path.join(EXT, 'shared', name)
    if os.path.exists(s_bg):
        shutil.copyfile(s_bg, os.path.join(MV2, name))

print('built index.html (%d chars), popup (%d chars)' % (len(INDEX), len(POPUP_JS)))
