/* ============================================================================
 * PhishGuard · background.js
 * Chromium MV3 service worker 与 Firefox 事件页共用同一份文件。
 * 只做一件事：首次安装时写入默认偏好，其余逻辑全部在 popup 内完成。
 * ========================================================================== */
const browserAPI = (typeof browser !== 'undefined') ? browser : chrome;

const DEFAULTS = {
  'phishguard.char': 'sakura',
  'phishguard.sound': false,
  'phishguard.theme': 'pink'
};

browserAPI.runtime.onInstalled.addListener(function (details) {
  if (details && details.reason && details.reason !== 'install') return;
  try {
    Promise.resolve(browserAPI.storage.local.get(Object.keys(DEFAULTS)))
      .then(function (current) {
        const patch = {};
        Object.keys(DEFAULTS).forEach(function (key) {
          if (!current || current[key] == null) patch[key] = DEFAULTS[key];
        });
        if (Object.keys(patch).length) return browserAPI.storage.local.set(patch);
        return undefined;
      })
      .catch(function () { /* 存储不可用时忽略 */ });
  } catch (e) { /* 忽略 */ }
});
