/* ============================================================================
 * PhishGuard · 浏览器插件弹窗交互（Chromium / Firefox 共用）
 * 兼容层：所有 chrome.* / browser.* 调用统一走 browserAPI。
 * ========================================================================== */
(function () {
  'use strict';

  const browserAPI = (typeof browser !== 'undefined') ? browser : chrome;

  const PG = window.PhishGuard;
  const UI = window.PGUI;
  const $ = UI.$;
  const $$ = UI.$$;

  const state = {
    char: 'sakura',
    sound: false,
    busy: false,
    last: null,
    history: [],
    expanded: false,
    clearArmed: false,
    mood: 'idle'
  };

  const el = {};
  function cacheDom() {
    [
      'urlInput', 'detectBtn', 'detectBar', 'resultCard', 'scoreRing', 'scoreNum',
      'resultTitle', 'levelText', 'levelPill', 'stampMini', 'popWho', 'popLine',
      'popReasons', 'popAll', 'popAllText', 'popHistoryList', 'popHistoryCount',
      'popClear', 'popSwitch', 'popCharaStage', 'popTip', 'useTab',
      'soundBtn', 'aboutBtn', 'aboutModal', 'aboutClose'
    ].forEach(function (id) { el[id] = document.getElementById(id); });
  }

  /* -------------------------------------------------------------- 偏好 --- */
  const prefs = {
    async get(key, fallback) {
      try {
        const obj = await browserAPI.storage.local.get(key);
        return obj && obj[key] != null ? obj[key] : fallback;
      } catch (e) { return fallback; }
    },
    set(key, value) {
      try { browserAPI.storage.local.set({ [key]: value }); } catch (e) { /* 忽略 */ }
    }
  };

  /* ------------------------------------------------------------ 基础 UI --- */
  const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  function setBusy(busy) {
    state.busy = busy;
    el.detectBtn.disabled = busy;
    el.detectBtn.querySelector('.btn-label').textContent = busy ? '分析中' : '检测';
    el.detectBtn.querySelector('.spark').textContent = busy ? '·' : '✨';
  }

  function setMood(mood) {
    state.mood = mood;
    el.resultCard.setAttribute('data-mood', mood);
    if (window.PhishGuardLive2D) window.PhishGuardLive2D.setMood(mood);
  }

  function say(text) {
    el.popLine.textContent = text;
  }

  /* ---------------------------------------------------------- 看板娘切换 --- */
  function renderSwitch() {
    el.popSwitch.innerHTML = PG.CHARS.map(function (c) {
      return UI.charButton(c, c.id === state.char);
    }).join('');
    el.popSwitch.addEventListener('click', function (e) {
      const btn = e.target.closest('.char-btn');
      if (!btn || btn.getAttribute('data-char') === state.char) return;
      setChar(btn.getAttribute('data-char'), true);
    });
  }

  function setChar(id, speak) {
    const c = PG.CHAR_MAP[id] || PG.CHARS[0];
    state.char = c.id;

    if (window.PhishGuardLive2D) window.PhishGuardLive2D.disposeIn(el.popCharaStage);
    el.popCharaStage.innerHTML = PG.charSVG(c.id);
    const svg = el.popCharaStage.querySelector('.chara-svg');
    if (svg && !matchMedia('(prefers-reduced-motion: reduce)').matches) svg.classList.add('swap');
    if (window.PhishGuardLive2D) {
      const kind = state.last ? (state.last.level === 'safe' ? 'happy' : (state.last.level === 'warn' ? 'warn' : 'danger')) : 'idle';
      window.PhishGuardLive2D.mountIn(el.popCharaStage, c.id, kind);
    }

    el.popWho.textContent = c.name;
    UI.$$('.char-btn').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-char') === c.id));
    });

    if (state.last) {
      const kind = state.last.level === 'safe' ? 'safe' : (state.last.level === 'warn' ? 'warn' : 'danger');
      setMood(kind === 'safe' ? 'happy' : kind);
      say(PG.lineFor(c.id, kind));
    } else if (speak) {
      setMood('idle');
      say(PG.lineFor(c.id, 'greet'));
    }

    prefs.set('phishguard.char', c.id);
  }

  /* ------------------------------------------------------------ 结果渲染 --- */
  const TITLE = { safe: '看起来很安全', warn: '有点可疑', danger: '很危险！' };

  function reasonHTML(r) {
    const sev = r.status === 'danger' ? 'danger' : 'warn';
    return '<div class="reason-item" data-sev="' + sev + '">'
      + '<span class="sev">' + (sev === 'danger' ? '!' : '?') + '</span>'
      + '<div class="txt"><div class="title-row"><b>' + UI.esc(r.title) + '</b>'
      + '<span class="weight">+' + r.weight + '</span></div>'
      + '<p>' + UI.esc(r.detail) + '</p></div></div>';
  }

  function checksHTML(results) {
    return results.map(function (r) {
      const mark = r.status === 'safe' ? '✓' : (r.status === 'danger' ? '!' : (r.status === 'warn' ? '?' : '·'));
      const st = r.status === 'safe' ? '通过' : (r.status === 'danger' ? '危险' : (r.status === 'warn' ? '可疑' : '—'));
      return '<div class="check-row" data-st="' + r.status + '">'
        + '<span class="mark">' + mark + '</span>'
        + '<span class="nm">' + UI.esc(r.title) + '</span>'
        + '<span class="st">' + st + '</span></div>';
    }).join('');
  }

  function renderReasons(res) {
    if (state.expanded && res) {
      el.popReasons.innerHTML = checksHTML(res.results);
      el.popAllText.textContent = '收起检测项';
      return;
    }
    if (!res) {
      el.popReasons.innerHTML = '<div class="pop-empty"><span class="big">0</span><span>还没有检测结果</span></div>';
      el.popAllText.textContent = '查看 12 项检测规则';
      return;
    }
    if (res.hits.length === 0) {
      el.popReasons.innerHTML = '<div class="reason-item" data-sev="safe">'
        + '<span class="sev">✓</span><div class="txt"><div class="title-row"><b>全部通过</b></div>'
        + '<p>12 项特征都没有命中，可以放心访问。</p></div></div>';
    } else {
      el.popReasons.innerHTML = res.hits.map(reasonHTML).join('');
    }
    el.popAllText.textContent = '查看全部 12 项';
  }

  function renderResult(res) {
    state.last = res;
    state.expanded = false;
    const meta = PG.levelMeta(res.level);

    el.resultCard.setAttribute('data-level', res.level);
    if (el.stampMini) el.stampMini.textContent = meta.label;
    el.resultTitle.textContent = TITLE[res.level];
    el.levelText.textContent = meta.label + ' ' + res.score + ' 分';
    UI.ringSet(el.scoreRing, res.score, res.level);
    UI.countUp(el.scoreNum, res.score, 700);

    renderReasons(res);

    const kind = res.level === 'safe' ? 'safe' : (res.level === 'warn' ? 'warn' : 'danger');
    setMood(kind === 'safe' ? 'happy' : kind);
    say(PG.lineFor(state.char, kind));
    UI.chime(res.level, state.sound);

    saveResult(res).then(renderHistory);
  }

  function renderError(msg) {
    state.last = null;
    state.expanded = false;
    el.resultCard.setAttribute('data-level', 'idle');
    if (el.stampMini) el.stampMini.textContent = '待机';
    el.resultTitle.textContent = '格式不对';
    el.levelText.textContent = '等待检测';
    UI.ringSet(el.scoreRing, 0, 'idle');
    UI.countUp(el.scoreNum, 0, 400);
    el.popReasons.innerHTML = '<div class="pop-empty"><span class="big">?</span><span>' + UI.esc(msg) + '</span></div>';
    el.popAllText.textContent = '查看 12 项检测规则';
    setMood('idle');
    say(PG.lineFor(state.char, 'error'));
    el.detectBar.classList.remove('anim-shake');
    void el.detectBar.offsetWidth;
    el.detectBar.classList.add('anim-shake');
  }

  /* -------------------------------------------------------------- 检测 --- */
  async function detect() {
    if (state.busy) return;
    const raw = (el.urlInput.value || '').trim();
    if (!raw) {
      say('先输入一个网址哦～');
      el.urlInput.focus();
      return;
    }
    const res = PG.analyze(raw);
    if (!res.ok) { renderError(res.error); return; }

    setBusy(true);
    setMood('thinking');
    say(PG.lineFor(state.char, 'thinking'));
    await sleep(620);
    setBusy(false);
    renderResult(res);
  }

  async function detectCurrentTab() {
    try {
      const tabs = await browserAPI.tabs.query({ active: true, currentWindow: true });
      const tab = tabs && tabs[0];
      if (!tab || !tab.url || !/^https?:/i.test(tab.url)) {
        el.popTip.textContent = '当前页面不是网页地址';
        return false;
      }
      el.urlInput.value = tab.url;
      await detect();
      return true;
    } catch (e) {
      el.popTip.textContent = '无法读取当前标签页';
      return false;
    }
  }

  /* ------------------------------------------------------------ 历史记录 --- */
  function renderHistory() {
    el.popHistoryCount.textContent = String(state.history.length);
    el.popClear.textContent = state.clearArmed ? '确认?' : '清空';
    if (!state.history.length) {
      el.popHistoryList.innerHTML = '<div class="pop-history-empty">还没有记录</div>';
      return;
    }
    el.popHistoryList.innerHTML = state.history.slice(0, 2).map(function (item) {
      return UI.historyRow(item, { hideTime: true });
    }).join('');
  }

  async function saveResult(res) {
    state.history = await PG.Store.add({ url: res.url, score: res.score, level: res.level, time: Date.now() });
  }

  function bindHistory() {
    el.popHistoryList.addEventListener('click', async function (e) {
      const row = e.target.closest('.hrow');
      if (!row) return;
      if (e.target.closest('.del')) {
        state.history = await PG.Store.remove(row.getAttribute('data-url'), Number(row.getAttribute('data-time')));
        renderHistory();
        return;
      }
      el.urlInput.value = row.getAttribute('data-url');
      el.urlInput.focus();
    });

    el.popClear.addEventListener('click', async function () {
      if (!state.history.length) return;
      if (!state.clearArmed) {
        state.clearArmed = true;
        renderHistory();
        setTimeout(function () {
          if (state.clearArmed) { state.clearArmed = false; renderHistory(); }
        }, 2500);
        return;
      }
      state.clearArmed = false;
      state.history = await PG.Store.clear();
      renderHistory();
    });
  }

  /* -------------------------------------------------------------- 弹窗 --- */
  function bindModal() {
    el.aboutBtn.addEventListener('click', function () { el.aboutModal.hidden = false; });
    el.aboutClose.addEventListener('click', function () { el.aboutModal.hidden = true; });
    el.aboutModal.addEventListener('click', function (e) {
      if (e.target === el.aboutModal) el.aboutModal.hidden = true;
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') el.aboutModal.hidden = true;
    });
  }

  /* -------------------------------------------------------------- 启动 --- */
  function bindCore() {
    el.detectBtn.addEventListener('click', detect);
    el.urlInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); detect(); }
    });
    el.useTab.addEventListener('click', detectCurrentTab);

    $$('[data-set-theme]').forEach(function (b) {
      b.addEventListener('click', function () { UI.applyTheme(b.getAttribute('data-set-theme')); });
    });

    el.soundBtn.addEventListener('click', function () {
      state.sound = !state.sound;
      el.soundBtn.setAttribute('aria-pressed', String(state.sound));
      el.soundBtn.setAttribute('aria-label', state.sound ? '关闭提示音' : '开启提示音');
      prefs.set('phishguard.sound', state.sound);
      if (state.sound) UI.chime('safe', true);
    });

    el.popAll.addEventListener('click', function () {
      state.expanded = !state.expanded;
      renderReasons(state.last);
    });
  }

  async function init() {
    cacheDom();

    UI.themeBackend = {
      get: function () { return prefs.get('phishguard.theme', 'pink'); },
      set: function (v) { prefs.set('phishguard.theme', v); }
    };
    await UI.initTheme();

    UI.spawnPetals(document.querySelector('.petals'), 8);

    PG.Store.backend = {
      get: async function () {
        const obj = await browserAPI.storage.local.get(PG.Store.KEY);
        return obj && Array.isArray(obj[PG.Store.KEY]) ? obj[PG.Store.KEY] : [];
      },
      set: async function (list) {
        const payload = {};
        payload[PG.Store.KEY] = list;
        await browserAPI.storage.local.set(payload);
      }
    };

    state.sound = await prefs.get('phishguard.sound', false);
    el.soundBtn.setAttribute('aria-pressed', String(!!state.sound));

    const savedChar = await prefs.get('phishguard.char', 'sakura');
    renderSwitch();
    bindCore();
    bindHistory();
    bindModal();
    setChar(PG.CHAR_MAP[savedChar] ? savedChar : 'sakura', true);

    state.history = await PG.Store.load();
    renderHistory();

    // 打开弹窗时自动检测当前标签页，失败则保持待机
    await detectCurrentTab();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
